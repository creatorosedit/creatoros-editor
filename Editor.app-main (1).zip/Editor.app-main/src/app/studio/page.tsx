"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { 
  ArrowLeft, Upload, Scissors, Play, Pause, ChevronLeft, ChevronRight, 
  ChevronsLeft, ChevronsRight, ZoomIn, ZoomOut, Maximize2, 
  X, Maximize, RotateCcw, Save, MonitorPlay, Menu, Type, Music, 
  Sparkles, AlignLeft, Trash2, Wrench, MousePointer2, Plus, Minus, 
  Settings2, Image as ImageIcon, Youtube, Instagram, Download, ChevronDown, Layers, CheckCircle2, Wand2
} from "lucide-react";
import { Suspense } from "react";
import { saveVideoToOPFS, getVideoFromOPFS } from "@/lib/video/opfs";
import { FFmpeg } from "@ffmpeg/ffmpeg";
import { fetchFile, toBlobURL } from "@ffmpeg/util";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { useRvmCutout } from "@/hooks/useRvmCutout";
import { FilesetResolver, ImageSegmenter } from "@mediapipe/tasks-vision";

type MainTab = "studio" | "thumbnail" | "publish" | "export";
type AspectFormat = "9:16" | "16:9" | "1:1" | "4:5" | "21:9";
type DragType = "timeline" | "left" | "right" | null;
type ToolType = "menu" | "cuts" | "text" | "audio" | "effects" | "captions" | "speed" | "masking";

const DEFAULT_LAYOUT = { timeline: 280, left: 240, right: 280 };
const COLOR_PRESETS = ["#ffffff", "#ffff00", "#ff4d4d", "#4ECDC4", "#3399ff", "#000000"];
const TRACKS = ["V0", "V1", "V2", "A1", "A2", "T1", "CC"] as const;

interface BaseClip { id: string; start: number; end: number; type: "video" | "text" | "audio" | "effect" | "image"; track: "v0" | "v1" | "v2" | "a1" | "a2" | "t1" | "cc"; }
interface VideoClip extends BaseClip { type: "video"; track: "v1" | "v2"; }
interface TextClip extends BaseClip { type: "text"; track: "t1" | "cc"; content: string; color: string; size: number; x: number; y: number; }
interface AudioClip extends BaseClip { type: "audio"; track: "a1" | "a2"; name: string; }
interface EffectClip extends BaseClip { type: "effect"; track: "v1" | "v2"; name: string; }
interface ImageClip extends BaseClip {
  type: "image";
  track: "v2" | "v0";
  url: string;
  prompt: string;
  layout: "full" | "half_top" | "half_bottom" | "half_left" | "half_right" | "overlay" | "background";
  animation?: "none" | "zoomIn" | "zoomOut" | "panLeft" | "panRight";
}
type Clip = VideoClip | TextClip | AudioClip | EffectClip | ImageClip;

interface WhisperTranscript {
  text: string;
  words?: TranscriptWord[];
}

interface TranscriptWord {
  word: string;
  start: number;
  end: number;
}

interface AlignmentCutSegment {
  start: number;
  end: number;
}

interface SilenceSegment {
  start: number;
  end: number;
}

interface AlignmentResult {
  correctedText: string;
  cutSegments: AlignmentCutSegment[];
  phrasesToCut: string[];
}

interface MagicEditSuggestion {
  startTime: number;
  endTime: number;
}

interface MagicEditVisual extends MagicEditSuggestion {
  prompt: string;
  layout: ImageClip["layout"];
}

const isMagicEditVisual = (value: unknown): value is MagicEditVisual =>
  typeof value === "object" &&
  value !== null &&
  "prompt" in value &&
  typeof value.prompt === "string" &&
  "startTime" in value &&
  typeof value.startTime === "number" &&
  "endTime" in value &&
  typeof value.endTime === "number" &&
  "layout" in value &&
  (value.layout === "full" ||
    value.layout === "half_top" ||
    value.layout === "half_bottom" ||
    value.layout === "half_left" ||
    value.layout === "half_right" ||
    value.layout === "overlay" ||
    value.layout === "background");

const isTranscriptWord = (word: unknown): word is TranscriptWord =>
  typeof word === "object" &&
  word !== null &&
  "word" in word &&
  typeof word.word === "string" &&
  "start" in word &&
  typeof word.start === "number" &&
  "end" in word &&
  typeof word.end === "number";

const isAlignmentCutSegment = (segment: unknown): segment is AlignmentCutSegment =>
  typeof segment === "object" &&
  segment !== null &&
  "start" in segment &&
  typeof segment.start === "number" &&
  "end" in segment &&
  typeof segment.end === "number";

export default function StudioPage() {
  return <Suspense fallback={<div className="fixed inset-0 bg-[#0a0a0a]" />}><StudioContent /></Suspense>;
}

function StudioContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const draftId = searchParams.get("id");

  const [activeTab, setActiveTab] = useState<MainTab>("studio");
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [timelineFrames, setTimelineFrames] = useState<string[]>([]);
  const [clips, setClips] = useState<Clip[]>([]);
  const [timelineDuration, setTimelineDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [fps, setFps] = useState(30);
  const [zoom, setZoom] = useState(1);
  const [previewZoom, setPreviewZoom] = useState(1);
  
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const [isMobilePropsOpen, setIsMobilePropsOpen] = useState(false);
  const [activeTool, setActiveTool] = useState<ToolType>("menu");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [isAutoEditing, setIsAutoEditing] = useState(false);
  const [autoEditStep, setAutoEditStep] = useState(0);
  const [autoEditLog, setAutoEditLog] = useState<string[]>([]);
  const [whisperData, setWhisperData] = useState<WhisperTranscript | null>(null);
  const [manualScript, setManualScript] = useState("");
  const [cutoutEnabled, setCutoutEnabled] = useState(false);
  const [cutoutEngine, setCutoutEngine] = useState<"mediapipe" | "rvm">("mediapipe");
  const [rvmRefine, setRvmRefine] = useState(1.0);
  const [silenceThreshold, setSilenceThreshold] = useState(0.5);
  const [alignmentData, setAlignmentData] = useState<AlignmentResult | null>(null);
  const [hasAppliedCuts, setHasAppliedCuts] = useState(false);
  const [isAligning, setIsAligning] = useState(false);
  const [splitLayout, setSplitLayout] = useState<"single" | "vertical" | "horizontal">("single");
  const [splitRatio, setSplitRatio] = useState(50);
  const [shapeMask, setShapeMask] = useState<"none" | "circle" | "rectangle">("none");
  const [circleSize, setCircleSize] = useState(50);
  const [rectInset, setRectInset] = useState(10);
  const [gradientMask, setGradientMask] = useState<"none" | "fadeLeft" | "fadeRight" | "fadeUp" | "fadeDown" | "fadeCenter">("none");
  const [maskX, setMaskX] = useState(50);
  const [maskY, setMaskY] = useState(50);
  const [gradientIntensity, setGradientIntensity] = useState(50);
  const [isFormatMenuOpen, setIsFormatMenuOpen] = useState(false);
  const [isGridVisible, setIsGridVisible] = useState(false);
  const [showOutOfBoundsAlert, setShowOutOfBoundsAlert] = useState(false);
  
  const [format, setFormat] = useState<AspectFormat>("9:16");
  const [isFill, setIsFill] = useState(false); 
  const [layout, setLayout] = useState(DEFAULT_LAYOUT);
  const [lockedTracks, setLockedTracks] = useState<string[]>([]);

  const [draggingTextId, setDraggingTextId] = useState<string | null>(null);
  const dragTextStartPos = useRef({ x: 0, y: 0, initialX: 0, initialY: 0 });
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [resizingClipId, setResizingClipId] = useState<string | null>(null);
  const [resizeDir, setResizeDir] = useState<"left" | "right" | null>(null);
  const resizeStartPos = useRef({ x: 0, initialStart: 0, initialEnd: 0 });

  const pinchDistRef = useRef<number>(0);
  const dragTypeRef = useRef<DragType>(null);
  const dragStartPosRef = useRef({ x: 0, y: 0 });
  const dragStartLayoutRef = useRef(DEFAULT_LAYOUT);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const rulerRef = useRef<HTMLDivElement>(null);
  const playheadRef = useRef<HTMLDivElement>(null);
  const manualScriptEditedRef = useRef(false);
  const rvm = useRvmCutout({
    enabled: cutoutEngine === "rvm" && cutoutEnabled,
    videoRef,
    canvasRef,
    previewMaxWidth: 854,
    refineStrength: rvmRefine,
    featherAmount: 0.35,
    temporalSmoothing: 0.3,
    backgroundColor: [20, 20, 20, 255],
  });

  useEffect(() => {
    if (rvm.status === "error" && cutoutEngine === "rvm") {
      setCutoutEngine("mediapipe");
    }
  }, [rvm.status, cutoutEngine]);

  const formatTime = (time: number) => `${Math.floor(time / 60).toString().padStart(2, "0")}:${Math.floor(time % 60).toString().padStart(2, "0")}:${Math.floor((time % 1) * 100).toString().padStart(2, "0")}`;
  const getTimelinePercent = useCallback((time: number) => (timelineDuration > 0 ? (time / timelineDuration) * 100 : 0), [timelineDuration]);

  useEffect(() => {
    let objectUrl: string | null = null;
    let cancelled = false;

    async function loadVideo() {
      if (!draftId) {
        setIsLoading(false);
        return;
      }

      try {
        const file = await getVideoFromOPFS(draftId);
        if (file && !cancelled) {
          objectUrl = URL.createObjectURL(file);
          setVideoUrl(objectUrl);
          void extractFilmstrip(objectUrl);
        }
      } catch (error) {
        console.error("Failed to load draft video:", error);
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    void loadVideo();
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [draftId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!cutoutEnabled) {
      const context = canvas?.getContext("2d");
      if (canvas && context) context.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }

    let cancelled = false;
    let animationFrameId = 0;
    let lastVideoTime = -1;
    let activeSegmenter: ImageSegmenter | null = null;

    const processFrame = () => {
      if (cancelled) return;

      const video = videoRef.current;
      if (video && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA &&
          video.videoWidth > 0 && video.currentTime !== lastVideoTime) {
        lastVideoTime = video.currentTime;

        if (cutoutEngine === "rvm") {
          if (rvm.status === "ready") {
            rvm.drawAsync();
          }
        } else if (activeSegmenter) {
          const targetCanvas = canvasRef.current;
          const context = targetCanvas?.getContext("2d");
          if (targetCanvas && context) {
            const scale = Math.min(1, 1280 / video.videoWidth, 720 / video.videoHeight);
            const width = Math.max(1, Math.round(video.videoWidth * scale));
            const height = Math.max(1, Math.round(video.videoHeight * scale));
            if (targetCanvas.width !== width || targetCanvas.height !== height) {
              targetCanvas.width = width;
              targetCanvas.height = height;
            }

            try {
              context.drawImage(video, 0, 0, width, height);
              const result = activeSegmenter.segmentForVideo(video, performance.now());
              const mask = result.categoryMask;
              if (mask) {
                const maskData = mask.getAsUint8Array();
                const imageData = context.getImageData(0, 0, width, height);
                const pixels = imageData.data;

                for (let y = 0; y < height; y++) {
                  const maskY = Math.min(mask.height - 1, Math.floor((y / height) * mask.height));
                  for (let x = 0; x < width; x++) {
                    const maskX = Math.min(mask.width - 1, Math.floor((x / width) * mask.width));
                    const backgroundAlpha =
                      maskData[maskY * mask.width + maskX] === 0 ? 255 : 0;
                    pixels[(y * width + x) * 4 + 3] = 255 - backgroundAlpha;
                  }
                }
                context.putImageData(imageData, 0, 0);
              }
              result.close();
            } catch (error: unknown) {
              console.error("MediaPipe frame segmentation failed:", error);
              setCutoutEnabled(false);
            }
          }
        }
      }

      if (!cancelled && (cutoutEngine !== "rvm" || rvm.status !== "error")) {
        animationFrameId = requestAnimationFrame(processFrame);
      }
    };

    const initMediaPipe = async () => {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm",
        );
        const createdSegmenter = await ImageSegmenter.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath:
              "https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite",
            delegate: "GPU",
          },
          runningMode: "VIDEO",
          outputCategoryMask: true,
          outputConfidenceMasks: false,
        });

        if (cancelled) {
          createdSegmenter.close();
          return;
        }
        activeSegmenter = createdSegmenter;
        processFrame();
      } catch (error: unknown) {
        if (!cancelled) {
          console.error("MediaPipe initialization failed:", error);
          setCutoutEnabled(false);
        }
      }
    };

    if (cutoutEngine === "rvm") {
      processFrame();
    } else {
      void initMediaPipe();
    }

    return () => {
      cancelled = true;
      cancelAnimationFrame(animationFrameId);
      activeSegmenter?.close();
    };
  }, [cutoutEnabled, cutoutEngine, videoUrl, rvm.status, rvm.drawAsync]);

  useEffect(() => {
    if (!draftId) return;

    let cancelled = false;
    getDoc(doc(db, "drafts", draftId))
      .then((snapshot) => {
        if (cancelled || manualScriptEditedRef.current || !snapshot.exists()) return;

        const script = snapshot.data().script;
        if (
          typeof script === "object" &&
          script !== null &&
          "full" in script &&
          typeof script.full === "string"
        ) {
          setManualScript(script.full);
        }
      })
      .catch((error: unknown) => {
        console.error("Failed to load draft script:", error);
      });

    return () => {
      cancelled = true;
    };
  }, [draftId]);

  // Smooth Playhead Engine
  useEffect(() => {
    let animationFrameId: number;
    const animatePlayhead = () => {
      if (videoRef.current && playheadRef.current && timelineDuration > 0) {
        const sourceTime = videoRef.current.currentTime;
        const videoClips = clips
          .filter((clip): clip is VideoClip => clip.type === "video")
          .sort((a, b) => a.start - b.start);
        let playheadTime = 0;
        for (const clip of videoClips) {
          if (sourceTime >= clip.start && sourceTime < clip.end) {
            playheadTime += sourceTime - clip.start;
            break;
          }
          if (sourceTime >= clip.end) playheadTime += clip.end - clip.start;
        }

        const percent = Math.min(getTimelinePercent(playheadTime), 100);
        playheadRef.current.style.left = `${percent}%`;
        
        const timecodeEl = playheadRef.current.querySelector('.playhead-timecode');
        if (timecodeEl) timecodeEl.innerHTML = formatTime(playheadTime);
      }
      if (isPlaying) animationFrameId = requestAnimationFrame(animatePlayhead);
    };
    if (isPlaying) animatePlayhead();
    return () => cancelAnimationFrame(animationFrameId);
  }, [clips, isPlaying, timelineDuration, getTimelinePercent]);

  // Scrub Logic
  const handleScrub = useCallback((clientX: number) => {
    if (!rulerRef.current || !videoRef.current || timelineDuration <= 0) return;
    const rect = rulerRef.current.getBoundingClientRect();
    if (rect.width === 0) return;
    const percentage = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const newTime = percentage * timelineDuration;

    let acc = 0, targetTime = 0;
    const vClips = clips.filter(c => c.type === "video") as VideoClip[];
    for (const c of vClips.sort((a,b)=>a.start-b.start)) {
      if (newTime <= acc + (c.end - c.start)) { targetTime = c.start + (newTime - acc); break; }
      acc += (c.end - c.start);
    }
    videoRef.current.currentTime = targetTime;
    setCurrentTime(newTime);
  }, [timelineDuration, clips]);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => { if (isScrubbing) handleScrub(e.clientX); };
    const onMouseUp = () => setIsScrubbing(false);
    const onTouchMove = (e: TouchEvent) => {
      const touch = e.touches.item(0);
      if (isScrubbing && touch) {
        e.preventDefault();
        handleScrub(touch.clientX);
      }
    };
    const onTouchEnd = () => setIsScrubbing(false);

    if (isScrubbing) {
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
      window.addEventListener('touchmove', onTouchMove, { passive: false });
      window.addEventListener('touchend', onTouchEnd);
    }
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
    };
  }, [isScrubbing, handleScrub]);

  const saveLayout = () => { localStorage.setItem("studio_layout", JSON.stringify(layout)); setIsMenuOpen(false); };
  const resetLayout = () => { setLayout(DEFAULT_LAYOUT); localStorage.removeItem("studio_layout"); setIsMenuOpen(false); };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const sourceTime = videoRef.current.currentTime;
    const videoClips = clips.filter(c => c.type === "video") as VideoClip[];
    if (videoClips.length === 0) return;

    const activeClip = videoClips.find(c => sourceTime >= c.start && sourceTime <= c.end);
    if (!activeClip) {
      const nextClip = videoClips.find(c => c.start > sourceTime);
      if (nextClip) videoRef.current.currentTime = nextClip.start;
      else { videoRef.current.pause(); setIsPlaying(false); setCurrentTime(timelineDuration); }
      return;
    }
    let tlTime = 0;
    for (const c of videoClips.sort((a,b)=>a.start-b.start)) {
      if (c.id === activeClip.id) { tlTime += (sourceTime - c.start); break; }
      else { tlTime += (c.end - c.start); }
    }
    setCurrentTime(tlTime);
  };

  const applyAlignmentCuts = (cutSegments: AlignmentCutSegment[]) => {
    const videoClips = clips
      .filter((clip): clip is VideoClip => clip.type === "video")
      .sort((a, b) => a.start - b.start);
    if (videoClips.length === 0 || cutSegments.length === 0) return 0;

    const sortedCuts = cutSegments
      .filter((cut) => Number.isFinite(cut.start) && Number.isFinite(cut.end) && cut.end > cut.start)
      .sort((a, b) => a.start - b.start);
    const mergedCuts: AlignmentCutSegment[] = [];
    for (const cut of sortedCuts) {
      const previous = mergedCuts[mergedCuts.length - 1];
      if (previous && cut.start <= previous.end) {
        previous.end = Math.max(previous.end, cut.end);
      } else {
        mergedCuts.push({ ...cut });
      }
    }

    let appliedCutCount = 0;
    const remainingVideoClips: VideoClip[] = [];
    for (const clip of videoClips) {
      let cursor = clip.start;
      let keptSegments = 0;
      let clipWasCut = false;

      for (const cut of mergedCuts) {
        const cutStart = Math.max(clip.start, cut.start);
        const cutEnd = Math.min(clip.end, cut.end);
        if (cutEnd <= cursor || cutEnd <= cutStart) continue;
        clipWasCut = true;

        if (cutStart > cursor) {
          remainingVideoClips.push({
            ...clip,
            id: keptSegments === 0 ? clip.id : crypto.randomUUID(),
            start: cursor,
            end: cutStart,
          });
          keptSegments += 1;
        }

        cursor = Math.max(cursor, cutEnd);
        appliedCutCount += 1;
      }

      if (!clipWasCut) {
        remainingVideoClips.push(clip);
      } else if (cursor < clip.end) {
        remainingVideoClips.push({
          ...clip,
          id: keptSegments === 0 ? clip.id : crypto.randomUUID(),
          start: cursor,
          end: clip.end,
        });
      }
    }

    if (appliedCutCount === 0) return 0;

    const updatedClips = [
      ...clips.filter((clip) => clip.type !== "video"),
      ...remainingVideoClips,
    ];
    const updatedVideoClips = remainingVideoClips.sort((a, b) => a.start - b.start);
    const updatedDuration = updatedVideoClips.reduce(
      (duration, clip) => duration + clip.end - clip.start,
      0,
    );

    setClips(updatedClips);
    setTimelineDuration(updatedDuration);
    setSelectedClipId((selectedId) =>
      selectedId && updatedClips.some((clip) => clip.id === selectedId) ? selectedId : null,
    );

    if (videoRef.current && updatedVideoClips.length > 0) {
      const sourceTime = videoRef.current.currentTime;
      const activeClip = updatedVideoClips.find(
        (clip) => sourceTime >= clip.start && sourceTime < clip.end,
      );
      const nextClip = updatedVideoClips.find((clip) => clip.start >= sourceTime);
      const targetClip = activeClip ?? nextClip ?? updatedVideoClips[updatedVideoClips.length - 1];

      if (targetClip) {
        const targetTime = activeClip
          ? sourceTime
          : nextClip
            ? targetClip.start
            : targetClip.end;
        videoRef.current.currentTime = targetTime;

        const elapsedBeforeClip = updatedVideoClips
          .slice(0, updatedVideoClips.indexOf(targetClip))
          .reduce((duration, clip) => duration + clip.end - clip.start, 0);
        setCurrentTime(elapsedBeforeClip + targetTime - targetClip.start);
      }
    } else if (videoRef.current) {
      videoRef.current.pause();
      setIsPlaying(false);
      setCurrentTime(0);
    }

    return appliedCutCount;
  };

  // FFmpeg Audio Extraction and Silence Detection
  const extractAudioWithFFmpeg = async (
    threshold: number,
  ): Promise<{ audioBlob: Blob; silenceSegments: SilenceSegment[] } | null> => {
    if (!draftId) return null;

    let ffmpeg: FFmpeg | null = null;
    let isLoaded = false;

    try {
      if (!Number.isFinite(threshold) || threshold <= 0) {
        throw new Error("Silence threshold must be a positive number");
      }

      setAutoEditLog((prev) => [...prev, "Loading FFmpeg Core..."]);

      ffmpeg = new FFmpeg();
      const baseURL = "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd";

      await ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, "text/javascript"),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, "application/wasm"),
      });
      isLoaded = true;

      const file = await getVideoFromOPFS(draftId);
      if (!file) throw new Error("Video file not found in OPFS");

      setAutoEditLog((prev) => [...prev, "Reading video from OPFS..."]);
      await ffmpeg.writeFile("input.mp4", await fetchFile(file));

      setAutoEditLog((prev) => [...prev, "Extracting 16kHz mono WAV audio..."]);
      await ffmpeg.exec([
        "-i",
        "input.mp4",
        "-vn",
        "-acodec",
        "pcm_s16le",
        "-ar",
        "16000",
        "-ac",
        "1",
        "output.wav",
      ]);

      const data = await ffmpeg.readFile("output.wav");
      if (typeof data === "string") {
        throw new Error("FFmpeg returned audio as text");
      }

      const audioBuffer = new ArrayBuffer(data.byteLength);
      new Uint8Array(audioBuffer).set(data);
      const audioBlob = new Blob([audioBuffer], { type: "audio/wav" });

      const silenceSegments: SilenceSegment[] = [];
      let currentSilenceStart: number | null = null;
      const handleSilenceLog = ({ message }: { message: string }) => {
        const startMatch = message.match(/silence_start:\s*(-?\d+(?:\.\d+)?)/);
        if (startMatch) {
          currentSilenceStart = Number(startMatch[1]);
        }

        const endMatch = message.match(/silence_end:\s*(-?\d+(?:\.\d+)?)/);
        if (endMatch && currentSilenceStart !== null) {
          const endTime = Number(endMatch[1]);
          if (endTime >= currentSilenceStart && endTime - currentSilenceStart >= threshold) {
            silenceSegments.push({ start: currentSilenceStart, end: endTime });
          }
          currentSilenceStart = null;
        }
      };

      setAutoEditLog((prev) => [...prev, `Detecting silences longer than ${threshold}s...`]);
      ffmpeg.on("log", handleSilenceLog);
      try {
        await ffmpeg.exec([
          "-i",
          "input.mp4",
          "-af",
          `silencedetect=noise=-35dB:d=${threshold}`,
          "-f",
          "null",
          "-",
        ]);
      } finally {
        ffmpeg.off("log", handleSilenceLog);
      }

      setAutoEditLog((prev) => [
        ...prev,
        `Audio ready. Found ${silenceSegments.length} silent segments.`,
      ]);
      return { audioBlob, silenceSegments };
    } catch (error) {
      console.error("FFmpeg Error:", error);
      const message = error instanceof Error ? error.message : String(error);
      setAutoEditLog((prev) => [...prev, `Error: FFmpeg processing failed: ${message}`]);
      return null;
    } finally {
      if (isLoaded) ffmpeg?.terminate();
    }
  };

const transcribeAudio = async (audioBlob: Blob): Promise<WhisperTranscript | null> => {
  try {
    const formData = new FormData();
    formData.append("audio", audioBlob, "audio.wav");

    const response = await fetch("/api/ai/whisper", {
      method: "POST",
      body: formData,
    });
    const responseText = await response.text();
    let result: unknown;
    try {
      result = responseText ? JSON.parse(responseText) : {};
    } catch {
      const responsePreview = responseText.slice(0, 50);
      const truncationSuffix = responseText.length > responsePreview.length ? "..." : "";
      if (!response.ok) {
        throw new Error(
          `Whisper Server Error: ${response.status}: ${responsePreview}${truncationSuffix}`,
        );
      }
      throw new Error(`Whisper Invalid JSON: ${responsePreview}${truncationSuffix}`);
    }

    if (typeof result !== "object" || result === null) {
      if (!response.ok) {
        throw new Error(`Whisper Server Error: ${response.status}`);
      }
      throw new Error("Whisper API returned an invalid response");
    }

    const payload = result as { success?: unknown; data?: unknown; error?: unknown };
    if (!response.ok || payload.success !== true || !("data" in payload)) {
      throw new Error(
        typeof payload.error === "string"
          ? payload.error
          : `Whisper Server Error: ${response.status}`,
      );
    }

    const data = payload.data;
    if (
      typeof data !== "object" ||
      data === null ||
      !("text" in data) ||
      typeof data.text !== "string"
    ) {
      throw new Error("Whisper API returned an invalid transcription");
    }

    const words = "words" in data ? data.words : undefined;
    if (
      words !== undefined &&
      (!Array.isArray(words) || !words.every(isTranscriptWord))
    ) {
      throw new Error("Whisper API returned invalid word timestamps");
    }

    const transcriptWords = Array.isArray(words) ? words.filter(isTranscriptWord) : undefined;
    setAutoEditLog((prev) => [...prev, "Whisper Transcription Successful!"]);
    return {
      text: data.text,
      words: transcriptWords,
    };
  } catch (error) {
    console.error("Whisper API Error:", error);
    return null;
  }
};

const alignScriptWithTranscript = async (
  transcriptData: WhisperTranscript,
): Promise<AlignmentResult | null> => {
  if (!manualScript.trim()) {
    setAutoEditLog((prev) => [...prev, "Skipping AI Alignment (No script provided)."]);
    return null;
  }

  setIsAligning(true);
  setAutoEditLog((prev) => [...prev, "Analyzing Script & Fixing Typos with AI..."]);

  try {
    const response = await fetch("/api/ai/align", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        script: manualScript,
        transcriptText: transcriptData.text,
        transcriptWords: transcriptData.words,
      }),
    });
    const responseText = await response.text();
    let result: unknown;
    try {
      result = JSON.parse(responseText);
    } catch {
      if (!response.ok) {
        throw new Error(`Server Error ${response.status}: ${responseText || response.statusText}`);
      }
      const responsePreview = responseText.slice(0, 50);
      const truncationSuffix = responseText.length > responsePreview.length ? "..." : "";
      throw new Error(`Alignment API returned invalid JSON: ${responsePreview}${truncationSuffix}`);
    }

    if (typeof result !== "object" || result === null) {
      if (!response.ok) {
        throw new Error(`Server Error ${response.status}: ${response.statusText}`);
      }
      throw new Error("Alignment API returned an invalid response");
    }

    const payload = result as { success?: unknown; data?: unknown; error?: unknown };
    if (!response.ok) {
      const serverError =
        typeof payload.error === "string" ? payload.error : response.statusText;
      throw new Error(`Server Error ${response.status}: ${serverError || "Request failed"}`);
    }
    if (payload.success !== true) {
      throw new Error(
        typeof payload.error === "string" ? payload.error : "AI alignment failed",
      );
    }

    const data = payload.data;
    if (
      typeof data !== "object" ||
      data === null ||
      !("correctedText" in data) ||
      typeof data.correctedText !== "string" ||
      !("cutSegments" in data) ||
      !Array.isArray(data.cutSegments) ||
      !data.cutSegments.every(isAlignmentCutSegment) ||
      !("phrasesToCut" in data) ||
      !Array.isArray(data.phrasesToCut) ||
      !data.phrasesToCut.every((phrase) => typeof phrase === "string")
    ) {
      throw new Error("Alignment API returned invalid alignment data");
    }

    const alignment: AlignmentResult = {
      correctedText: data.correctedText,
      cutSegments: data.cutSegments.filter(isAlignmentCutSegment),
      phrasesToCut: data.phrasesToCut,
    };
    setAlignmentData(alignment);
    setAutoEditLog((prev) => [...prev, "AI Alignment Successful! Cuts detected."]);
    return alignment;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown alignment error";
    console.error("Alignment Error:", error);
    setAutoEditLog((prev) => [...prev, `Alignment Error: ${message}`]);
    return null;
  } finally {
    setIsAligning(false);
  }
};

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) videoRef.current.pause();
    else {
      if (currentTime >= timelineDuration - 0.1) { videoRef.current.currentTime = clips.find(c=>c.type==="video")?.start || 0; setCurrentTime(0); }
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const stepFrame = (dir: "forward" | "backward") => {
    if (!videoRef.current) return;
    const step = 1 / fps;
    videoRef.current.currentTime += dir === "forward" ? step : -step;
  };

  const seekTime = (seconds: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime += seconds;
  };

  const extractFilmstrip = async (url: string) => {
    const video = document.createElement("video"); video.src = url; video.muted = true;
    await new Promise((resolve) => { video.onloadedmetadata = resolve; });
    const frames = []; const canvas = document.createElement("canvas");
    canvas.width = 160; canvas.height = 90; const ctx = canvas.getContext("2d");
    for (let i = 0; i < 15; i++) {
      video.currentTime = (video.duration / 15) * i;
      await new Promise((resolve) => { video.onseeked = resolve; });
      if (ctx) { ctx.drawImage(video, 0, 0, canvas.width, canvas.height); frames.push(canvas.toDataURL("image/jpeg", 0.5)); }
    }
    setTimelineFrames(frames);
  };

  const onVideoLoaded = () => {
    if (!videoRef.current) return;
    setTimelineDuration(videoRef.current.duration);
    setClips([{ id: crypto.randomUUID(), type: "video", track: "v1", start: 0, end: videoRef.current.duration }]);
    const ratio = videoRef.current.videoWidth / videoRef.current.videoHeight;
    setFormat(ratio > 1.5 ? "16:9" : "9:16");

    const video = videoRef.current;
    if (typeof video.requestVideoFrameCallback === "function") {
      let frameCount = 0; let startTime = 0;
      const checkFps = (_now: number, metadata: VideoFrameCallbackMetadata) => {
        if (frameCount === 0) startTime = metadata.mediaTime;
        if (frameCount === 10) {
          const calculatedFps = 10 / (metadata.mediaTime - startTime);
          if (calculatedFps >= 23 && calculatedFps <= 121) setFps(Math.round(calculatedFps));
          return;
        }
        frameCount++;
        video.requestVideoFrameCallback(checkFps);
      };
      video.requestVideoFrameCallback(checkFps);
    }
  };

  const runMagicEdit = async () => {
    if (!manualScript.trim()) {
      window.alert("Please paste the original script first to run Magic Edit.");
      return;
    }

    setIsAutoEditing(true);
    setAutoEditStep(1);
    setAutoEditLog(["Starting Magic Edit...", "AI Director is analyzing script..."]);

    try {
      const response = await fetch("/api/ai/magic-edit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          script: manualScript,
          format,
          videoDuration: timelineDuration,
        }),
      });
      const responseText = await response.text();
      let result: unknown;
      try {
        result = responseText ? JSON.parse(responseText) : {};
      } catch {
        const responsePreview = responseText.slice(0, 50);
        const truncationSuffix = responseText.length > responsePreview.length ? "..." : "";
        if (!response.ok) {
          throw new Error(
            `Server Error ${response.status}: ${responsePreview}${truncationSuffix}`,
          );
        }
        throw new Error(
          `Magic Edit API returned invalid JSON: ${responsePreview}${truncationSuffix}`,
        );
      }

      if (typeof result !== "object" || result === null) {
        if (!response.ok) {
          throw new Error(`Server Error: ${response.status}`);
        }
        throw new Error("Magic Edit API returned an invalid response.");
      }

      const payload = result as { success?: unknown; data?: unknown; error?: unknown };
      if (!response.ok || payload.success !== true) {
        throw new Error(
          typeof payload.error === "string"
            ? payload.error
            : `Server Error: ${response.status}`,
        );
      }

      if (typeof payload.data !== "object" || payload.data === null) {
        throw new Error("Magic Edit API returned invalid suggestion data.");
      }

      const data = payload.data as {
        visuals?: unknown;
      };
      if (!Array.isArray(data.visuals)) {
        throw new Error("Magic Edit API returned invalid visual suggestions.");
      }

      const duration = Math.max(0, timelineDuration);
      const clampSuggestion = (suggestion: MagicEditSuggestion) => ({
        start: Math.max(0, Math.min(duration, suggestion.startTime)),
        end: Math.max(0, Math.min(duration, suggestion.endTime)),
      });
      const visuals = data.visuals
        .filter(isMagicEditVisual)
        .map((visual) => ({ ...visual, ...clampSuggestion(visual) }))
        .filter((visual) => visual.end > visual.start && visual.prompt.trim().length > 0);

      if (visuals.length === 0) {
        throw new Error("Magic Edit did not return any usable visual suggestions.");
      }

      setAutoEditStep(4);
      setAutoEditLog((previousLogs) => [
        ...previousLogs,
        "🤖 AI generating and placing visuals...",
      ]);

      const newClips: Clip[] = [];
      const animations = ["zoomIn", "zoomOut", "panLeft", "panRight"] as const;
      for (const visual of visuals) {
        setAutoEditLog((previousLogs) => [
          ...previousLogs,
          `Generating: "${visual.prompt.substring(0, 20)}..."`,
        ]);

        try {
          let width = 1024;
          let height = 1024;
          if (visual.layout === "full" || visual.layout === "background") {
            if (format === "9:16") {
              width = 576;
              height = 1024;
            } else if (format === "16:9") {
              width = 1024;
              height = 576;
            }
          }

          const imageResponse = await fetch("/api/ai/generate-image", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt: visual.prompt, width, height }),
          });
          const imageResult: unknown = await imageResponse.json();

          if (typeof imageResult !== "object" || imageResult === null) {
            throw new Error("Image generation returned an invalid response.");
          }

          const imagePayload = imageResult as {
            success?: unknown;
            image?: unknown;
            error?: unknown;
          };
          if (
            !imageResponse.ok ||
            imagePayload.success !== true ||
            typeof imagePayload.image !== "string" ||
            imagePayload.image.length === 0
          ) {
            throw new Error(
              typeof imagePayload.error === "string"
                ? imagePayload.error
                : "Image generation failed.",
            );
          }

          newClips.push({
            id: crypto.randomUUID(),
            type: "image",
            track: visual.layout === "background" ? "v0" : "v2",
            start: visual.start,
            end: visual.end,
            url: imagePayload.image.startsWith("data:")
              ? imagePayload.image
              : `data:image/jpeg;base64,${imagePayload.image}`,
            prompt: visual.prompt,
            layout: visual.layout,
            animation: animations[Math.floor(Math.random() * animations.length)],
          });
        } catch (error: unknown) {
          const message = error instanceof Error ? error.message : "Unknown image generation error.";
          setAutoEditLog((previousLogs) => [
            ...previousLogs,
            `⚠️ Failed: ${message}`,
          ]);
        }
      }

      setClips((previousClips) => [...previousClips, ...newClips]);
      setAutoEditLog((previousLogs) => [
        ...previousLogs,
        `✅ Generated ${newClips.length} Visuals successfully!`,
      ]);
      setAutoEditStep(8);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Unknown Magic Edit error.";
      console.error("Magic Edit Error:", error);
      setAutoEditLog((previousLogs) => [...previousLogs, `Magic Edit Error: ${message}`]);
      setAutoEditStep(0);
    }
  };

  const addClip = (type: "text" | "audio" | "effect") => {
    let newClip: Clip;
    const base = { id: crypto.randomUUID(), start: currentTime, end: Math.min(currentTime + 3, timelineDuration) };
    if (type === "text") newClip = { ...base, type: "text", track: "t1", content: "New Text", color: "#ffffff", size: 32, x: 50, y: 50 };
    else if (type === "audio") newClip = { ...base, type: "audio", track: "a1", name: "SFX_Track.mp3" };
    else newClip = { ...base, type: "effect", track: "v1", name: "Cinematic LUT" };
    setClips([...clips, newClip]);
    setSelectedClipId(newClip.id);
    setIsToolsOpen(false);
    if (window.innerWidth < 768) setIsMobilePropsOpen(true);
  };

  const updateTextClip = (id: string, updates: Partial<TextClip>) => {
    setClips(clips.map(c => c.id === id ? { ...c, ...updates } as TextClip : c));
  };

  const splitClip = () => {
    if (!selectedClipId || !videoRef.current) return;
    const sourceTime = videoRef.current.currentTime;
    const clipToSplit = clips.find(c => c.id === selectedClipId);
    if (clipToSplit && sourceTime > clipToSplit.start + 0.1 && sourceTime < clipToSplit.end - 0.1) {
      const newClips = clips.filter(c => c.id !== selectedClipId);
      newClips.push({ ...clipToSplit, id: crypto.randomUUID(), end: sourceTime });
      newClips.push({ ...clipToSplit, id: crypto.randomUUID(), start: sourceTime });
      setClips(newClips);
      setTimelineDuration(newClips.filter(c=>c.type==="video").reduce((acc, c) => acc + (c.end - c.start), 0));
      setSelectedClipId(null);
    }
  };

  const deleteClip = () => {
    if (!selectedClipId) return;
    const newClips = clips.filter(c => c.id !== selectedClipId);
    setClips(newClips);
    if (newClips.filter(c => c.type === "video").length === 0) setTimelineDuration(0);
    else setTimelineDuration(newClips.filter(c=>c.type==="video").reduce((acc, c) => acc + (c.end - c.start), 0));
    setSelectedClipId(null);
    setIsMobilePropsOpen(false);
  };

  const handleTextDragStart = (e: React.MouseEvent | React.TouchEvent, txt: TextClip) => {
    e.stopPropagation(); setSelectedClipId(txt.id); setDraggingTextId(txt.id);
    let clientX: number;
    let clientY: number;
    if ("touches" in e) {
      const touch = e.touches.item(0);
      if (!touch) return;
      clientX = touch.clientX;
      clientY = touch.clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    dragTextStartPos.current = { x: clientX, y: clientY, initialX: txt.x, initialY: txt.y };
  };
  const handleTextDragMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!draggingTextId || !videoContainerRef.current) return;
    let clientX: number;
    let clientY: number;
    if ("touches" in e) {
      const touch = e.touches.item(0);
      if (!touch) return;
      clientX = touch.clientX;
      clientY = touch.clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    const deltaX = clientX - dragTextStartPos.current.x; const deltaY = clientY - dragTextStartPos.current.y;
    const rect = videoContainerRef.current.getBoundingClientRect();
    const rawX = dragTextStartPos.current.initialX + (deltaX / rect.width) * 100;
    const rawY = dragTextStartPos.current.initialY + (deltaY / rect.height) * 100;

    // Agar text border se bahar jata hai toh alert dikhao
    if (rawX < 0 || rawX > 100 || rawY < 0 || rawY > 100) {
      if (!showOutOfBoundsAlert) {
          setShowOutOfBoundsAlert(true);
              setTimeout(() => setShowOutOfBoundsAlert(false), 2000);
                }
                }

                const newX = Math.max(0, Math.min(100, rawX));
                const newY = Math.max(0, Math.min(100, rawY));

                setClips(prev => prev.map(c => c.id === draggingTextId ? { ...c, x: newX, y: newY } as TextClip : c));
  }, [draggingTextId, showOutOfBoundsAlert]);
  const handleTextDragEnd = useCallback(() => { setDraggingTextId(null); }, []);

  const handleClipResizeStart = (e: React.MouseEvent | React.TouchEvent, clip: Clip, dir: "left"|"right") => {
    e.stopPropagation(); setResizingClipId(clip.id); setResizeDir(dir);
    let clientX: number;
    if ("touches" in e) {
      const touch = e.touches.item(0);
      if (!touch) return;
      clientX = touch.clientX;
    } else {
      clientX = e.clientX;
    }
    resizeStartPos.current = { x: clientX, initialStart: clip.start, initialEnd: clip.end };
  };
  const handleClipResizeMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!resizingClipId || !resizeDir || !timelineRef.current) return;
    let clientX: number;
    if ("touches" in e) {
      const touch = e.touches.item(0);
      if (!touch) return;
      clientX = touch.clientX;
    } else {
      clientX = e.clientX;
    }
    const deltaX = clientX - resizeStartPos.current.x;
    const timeDelta = (deltaX / (timelineRef.current.getBoundingClientRect().width * zoom)) * timelineDuration;
    setClips(prev => prev.map(c => {
      if (c.id !== resizingClipId) return c;
      if (resizeDir === "left") return { ...c, start: Math.max(0, Math.min(c.end - 0.1, resizeStartPos.current.initialStart + timeDelta)) };
      else return { ...c, end: Math.max(c.start + 0.1, Math.min(timelineDuration, resizeStartPos.current.initialEnd + timeDelta)) };
    }));
  }, [resizingClipId, resizeDir, zoom, timelineDuration]);
  const handleClipResizeEnd = useCallback(() => { setResizingClipId(null); setResizeDir(null); }, []);

  const startDragLayout = (e: React.MouseEvent | React.TouchEvent, type: DragType) => {
    if (e.cancelable) e.preventDefault();
    dragTypeRef.current = type;
    if ("touches" in e) {
      const touch = e.touches.item(0);
      if (!touch) return;
      dragStartPosRef.current = { x: touch.clientX, y: touch.clientY };
    } else {
      dragStartPosRef.current = { x: e.clientX, y: e.clientY };
    }
    dragStartLayoutRef.current = { ...layout };
  };
  const onLayoutDragMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!dragTypeRef.current) return;
    let clientX: number;
    let clientY: number;
    if ("touches" in e) {
      const touch = e.touches.item(0);
      if (!touch) return;
      clientX = touch.clientX;
      clientY = touch.clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    const deltaX = clientX - dragStartPosRef.current.x; const deltaY = dragStartPosRef.current.y - clientY;
    if (dragTypeRef.current === "timeline") { const h = dragStartLayoutRef.current.timeline + deltaY; setLayout(p => ({ ...p, timeline: Math.max(150, Math.min(window.innerHeight * 0.7, h)) })); }
    else if (dragTypeRef.current === "left") { const w = dragStartLayoutRef.current.left + deltaX; setLayout(p => ({ ...p, left: Math.max(200, Math.min(400, w)) })); }
    else if (dragTypeRef.current === "right") { const w = dragStartLayoutRef.current.right - deltaX; setLayout(p => ({ ...p, right: Math.max(200, Math.min(400, w)) })); }
  }, []);
  const onLayoutDragEnd = useCallback(() => { dragTypeRef.current = null; }, []);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const firstTouch = e.touches.item(0);
      const secondTouch = e.touches.item(1);
      if (firstTouch && secondTouch) {
        pinchDistRef.current = Math.hypot(firstTouch.clientX - secondTouch.clientX, firstTouch.clientY - secondTouch.clientY);
      }
    }
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && pinchDistRef.current > 0) {
      const firstTouch = e.touches.item(0);
      const secondTouch = e.touches.item(1);
      if (!firstTouch || !secondTouch) return;
      const dist = Math.hypot(firstTouch.clientX - secondTouch.clientX, firstTouch.clientY - secondTouch.clientY);
      if (Math.abs(dist - pinchDistRef.current) > 10) { setZoom(z => Math.max(0.5, Math.min(5, z + (dist - pinchDistRef.current) * 0.005))); pinchDistRef.current = dist; }
    }
  };

  useEffect(() => {
    window.addEventListener("mousemove", handleTextDragMove); window.addEventListener("mouseup", handleTextDragEnd);
    window.addEventListener("touchmove", handleTextDragMove, { passive: false }); window.addEventListener("touchend", handleTextDragEnd);
    window.addEventListener("mousemove", handleClipResizeMove); window.addEventListener("mouseup", handleClipResizeEnd);
    window.addEventListener("touchmove", handleClipResizeMove, { passive: false }); window.addEventListener("touchend", handleClipResizeEnd);
    window.addEventListener("mousemove", onLayoutDragMove); window.addEventListener("mouseup", onLayoutDragEnd);
    window.addEventListener("touchmove", onLayoutDragMove, { passive: false }); window.addEventListener("touchend", onLayoutDragEnd);
    return () => {
      window.removeEventListener("mousemove", handleTextDragMove); window.removeEventListener("mouseup", handleTextDragEnd);
      window.removeEventListener("touchmove", handleTextDragMove); window.removeEventListener("touchend", handleTextDragEnd);
      window.removeEventListener("mousemove", handleClipResizeMove); window.removeEventListener("mouseup", handleClipResizeEnd);
      window.removeEventListener("touchmove", handleClipResizeMove); window.removeEventListener("touchend", handleClipResizeEnd);
      window.removeEventListener("mousemove", onLayoutDragMove); window.removeEventListener("mouseup", onLayoutDragEnd);
      window.removeEventListener("touchmove", onLayoutDragMove); window.removeEventListener("touchend", onLayoutDragEnd);
    };
  }, [handleTextDragMove, handleTextDragEnd, handleClipResizeMove, handleClipResizeEnd, onLayoutDragMove, onLayoutDragEnd]);

  const activeTextClips = clips.filter(c => c.type === "text" && currentTime >= c.start && currentTime <= c.end) as TextClip[];
  const activeImageClips = clips.filter((clip): clip is ImageClip =>
    clip.type === "image" && currentTime >= clip.start && currentTime <= clip.end,
  );
  const renderImageClip = (imageClip: ImageClip) => {
    const duration = imageClip.end - imageClip.start;
    const progress = duration > 0
      ? Math.max(0, Math.min(1, (currentTime - imageClip.start) / duration))
      : 0;
    let transform = "scale(1) translate(0%, 0%)";

    if (imageClip.animation === "zoomIn") transform = `scale(${1 + progress * 0.3})`;
    if (imageClip.animation === "zoomOut") transform = `scale(${1.3 - progress * 0.3})`;
    if (imageClip.animation === "panLeft") {
      transform = `scale(1.2) translate(${10 - progress * 20}%, 0%)`;
    }
    if (imageClip.animation === "panRight") {
      transform = `scale(1.2) translate(${-10 + progress * 20}%, 0%)`;
    }

    let layoutClass = "absolute inset-0 h-full w-full object-cover";
    let zIndex = 30;

    switch (imageClip.layout) {
      case "half_top":
        layoutClass = "absolute left-0 top-0 h-1/2 w-full border-b border-[#4ECDC4]/30";
        break;
      case "half_bottom":
        layoutClass = "absolute bottom-0 left-0 h-1/2 w-full border-t border-[#4ECDC4]/30";
        break;
      case "half_left":
        layoutClass = "absolute left-0 top-0 h-full w-1/2 border-r border-[#4ECDC4]/30";
        break;
      case "half_right":
        layoutClass = "absolute right-0 top-0 h-full w-1/2 border-l border-[#4ECDC4]/30";
        break;
      case "overlay":
        layoutClass = "absolute bottom-4 right-4 h-1/3 w-1/3";
        break;
      case "background":
        zIndex = 0;
        break;
    }

    return (
      <div
        key={imageClip.id}
        className={`${layoutClass} pointer-events-none overflow-hidden`}
        style={{ zIndex }}
      >
        <img
          src={imageClip.url}
          alt={imageClip.prompt}
          className={`h-full w-full ${imageClip.layout === "overlay" ? "object-contain drop-shadow-2xl" : "object-cover"}`}
          style={{ transform, transition: "transform 0.1s linear" }}
        />
      </div>
    );
  };
  const selectedClip = clips.find(c => c.id === selectedClipId);

  const getAspectClass = () => {
      switch (format) {
          case "9:16": return "aspect-[9/16] h-full max-w-full";
              case "16:9": return "aspect-video w-full max-h-full";
                  case "1:1": return "aspect-square h-full max-w-full";
                      case "4:5": return "aspect-[4/5] h-full max-w-full";
                          case "21:9": return "aspect-[21/9] w-full max-h-full";
                              default: return "aspect-video w-full max-h-full";
                                }
                                };
                                
    const renderInspector = () => {
    if (!selectedClip) return <div className="text-center text-gray-500 mt-10 text-xs p-4">Select a clip to edit.</div>;
    
    if (selectedClip.type === "text") {
      return (
        <div className="space-y-4">
          <div>
            <div className="text-[10px] text-[#4ECDC4] font-bold mb-2 uppercase">Text Content</div>
            <textarea value={selectedClip.content} onChange={(e) => updateTextClip(selectedClip.id, { content: e.target.value })} className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-[#4ECDC4] resize-none" rows={2} />
          </div>
          <div>
            <div className="flex justify-between items-center mb-2"><div className="text-[10px] text-[#4ECDC4] font-bold uppercase">Size ({selectedClip.size}px)</div></div>
            <div className="flex items-center gap-2">
              <button onClick={() => updateTextClip(selectedClip.id, { size: Math.max(10, selectedClip.size - 2) })} className="p-1.5 bg-[#1a1a1a] rounded hover:bg-white/10"><Minus size={14}/></button>
              <input type="range" min="10" max="150" value={selectedClip.size} onChange={(e) => updateTextClip(selectedClip.id, { size: parseInt(e.target.value) })} className="flex-1 accent-[#4ECDC4]" />
              <button onClick={() => updateTextClip(selectedClip.id, { size: Math.min(150, selectedClip.size + 2) })} className="p-1.5 bg-[#1a1a1a] rounded hover:bg-white/10"><Plus size={14}/></button>
            </div>
          </div>
          <div>
            <div className="text-[10px] text-[#4ECDC4] font-bold mb-2 uppercase">Color</div>
            <div className="flex gap-2 flex-wrap mb-2">
              {COLOR_PRESETS.map(c => (<button key={c} onClick={() => updateTextClip(selectedClip.id, { color: c })} className="w-7 h-7 rounded-full border border-white/20" style={{ backgroundColor: c }} />))}
              <input type="color" value={selectedClip.color} onChange={(e) => updateTextClip(selectedClip.id, { color: e.target.value })} className="w-7 h-7 rounded cursor-pointer bg-transparent border-none" />
            </div>
          </div>
          <div>
            <div className="text-[10px] text-[#4ECDC4] font-bold mb-2 uppercase">Position</div>
            <div className="grid grid-cols-3 gap-2">
              <button onClick={() => updateTextClip(selectedClip.id, { x: 50, y: 15 })} className="py-1.5 bg-[#1a1a1a] rounded text-xs hover:bg-[#4ECDC4]/20">Top</button>
              <button onClick={() => updateTextClip(selectedClip.id, { x: 50, y: 50 })} className="py-1.5 bg-[#1a1a1a] rounded text-xs hover:bg-[#4ECDC4]/20">Center</button>
              <button onClick={() => updateTextClip(selectedClip.id, { x: 50, y: 85 })} className="py-1.5 bg-[#1a1a1a] rounded text-xs hover:bg-[#4ECDC4]/20">Bottom</button>
            </div>
          </div>
        </div>
      );
    }
    
    if (selectedClip.type === "image") {
      return (
        <div className="space-y-4">
          <div className="text-[10px] text-[#4ECDC4] font-bold uppercase">AI B-Roll</div>
          <p className="text-xs text-gray-300">{selectedClip.prompt}</p>
          <img src={selectedClip.url} alt={selectedClip.prompt} className="w-full rounded-lg object-cover" />
          <div className="flex items-center justify-between rounded-lg border border-white/5 bg-[#1a1a1a] p-2">
            <span className="text-xs text-gray-300">Remove Background (AI Cutout)</span>
            <label className="relative inline-flex cursor-pointer items-center">
              <input
                type="checkbox"
                checked={cutoutEnabled}
                onChange={(event) => setCutoutEnabled(event.target.checked)}
                className="peer sr-only"
                aria-label="Remove image background"
              />
              <span className="relative h-5 w-9 rounded-full bg-gray-600 transition-colors after:absolute after:left-[2px] after:top-[2px] after:h-4 after:w-4 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-transform peer-checked:bg-[#4ECDC4] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-[#4ECDC4]" />
            </label>
          </div>
        </div>
      );
    }

    if (selectedClip.type === "audio") return <div className="text-xs text-gray-400">Audio Volume / Ducking (Mock)</div>;
    if (selectedClip.type === "effect") return <div className="text-xs text-gray-400">Effect Intensity (Mock)</div>;
    
    return (
      <div className="space-y-4">
        <div className="text-[10px] text-[#4ECDC4] font-bold uppercase mb-2">Video Properties</div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-gray-400">Scale</span>
          <span className="bg-[#1a1a1a] px-2 py-1 rounded">100%</span>
        </div>
        <div className="flex items-center justify-between bg-[#1a1a1a] p-3 rounded-lg border border-white/5 mt-4">
          <div>
            <span className="text-xs text-gray-200 font-medium">AI Cutout (Remove Background)</span>
            <p className="text-[10px] text-gray-500 mt-0.5">Green screen ke bina background hataye</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={cutoutEnabled}
              onChange={(event) => setCutoutEnabled(event.target.checked)}
              className="peer sr-only"
              aria-label="Remove video background"
            />
            <span className="relative h-5 w-9 rounded-full bg-[#262626] transition-colors after:absolute after:left-[2px] after:top-[2px] after:h-4 after:w-4 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-transform peer-checked:bg-[#4ECDC4] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-[#4ECDC4]" />
          </label>
        </div>
        <div className="flex items-center gap-2">
          <label htmlFor="cutout-engine" className="text-xs text-gray-400">Cutout Engine</label>
          <select
            id="cutout-engine"
            value={cutoutEngine}
            onChange={(event) =>
              setCutoutEngine(event.target.value === "rvm" ? "rvm" : "mediapipe")
            }
            className="rounded bg-zinc-800 px-2 py-1 text-xs text-white"
          >
            <option value="mediapipe">MediaPipe (Fast)</option>
            <option value="rvm">RVM (High Quality)</option>
          </select>
        </div>
        {cutoutEngine === "rvm" && (
          <div className="mt-2 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">RVM Status</span>
              <span
                aria-live="polite"
                className={
                  rvm.status === "ready"
                    ? "text-green-400"
                    : rvm.status === "loading"
                      ? "text-yellow-400"
                      : rvm.status === "error"
                        ? "text-red-400"
                        : "text-gray-500"
                }
              >
                {rvm.status === "ready"
                  ? `✓ ${rvm.ep} · ${rvm.fps} FPS · ${rvm.inferenceMs}ms`
                  : rvm.status === "loading"
                    ? "Loading model..."
                    : rvm.error || "Idle"}
              </span>
            </div>
            {rvm.status === "ready" && (
              <div>
                <label htmlFor="rvm-refine" className="text-xs text-gray-400">
                  Refine Edges: {Math.round(rvmRefine * 100)}%
                </label>
                <input
                  id="rvm-refine"
                  type="range"
                  min="0.5"
                  max="1"
                  step="0.05"
                  value={rvmRefine}
                  onChange={(event) => setRvmRefine(Number.parseFloat(event.target.value))}
                  className="w-full"
                />
                <p className="text-[10px] text-gray-500">
                  Adjusts foreground opacity; feathering controls edge softness.
                </p>
              </div>
            )}
          </div>
        )}
      
      {/* AI Transcript Section */}
      <div className="mt-6 border-t border-white/5 pt-4">
        <div className="text-[10px] text-[#4ECDC4] font-bold uppercase mb-2">AI Transcript</div>
        <label className="block text-[10px] text-gray-400 mb-2" htmlFor="manual-script">
          Original script
        </label>
        <textarea
          id="manual-script"
          value={manualScript}
          onChange={(event) => {
            manualScriptEditedRef.current = true;
            setManualScript(event.target.value);
            setAlignmentData(null);
          }}
          placeholder="Paste or edit the original script..."
          className="w-full min-h-24 bg-[#1a1a1a] border border-white/10 rounded-lg p-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-[#4ECDC4] resize-y mb-3"
        />
        {whisperData ? (
          <div className="space-y-2">
            <div className="bg-[#1a1a1a] border border-white/5 p-2 rounded text-[10px] text-gray-300 h-32 overflow-y-auto leading-relaxed">
              {whisperData.text || "No text found"}
            </div>
            <div className="text-[10px] text-gray-500 font-mono text-right">
              {whisperData.words?.length || 0} words detected
            </div>
            <button
              type="button"
              onClick={() => void alignScriptWithTranscript(whisperData)}
              disabled={!manualScript.trim() || isAligning}
              className="w-full py-2 rounded-lg bg-[#4ECDC4]/10 text-[#4ECDC4] border border-[#4ECDC4]/30 text-xs font-bold disabled:opacity-40"
            >
              {isAligning ? "Aligning script..." : "Align Script"}
            </button>
            {alignmentData && (
              <div className="space-y-2 pt-2">
                <div className="text-[10px] text-[#4ECDC4] font-bold uppercase">
                  Corrected script
                </div>
                <div className="bg-[#1a1a1a] border border-white/5 p-2 rounded text-[10px] text-gray-300 max-h-32 overflow-y-auto whitespace-pre-wrap">
                  {alignmentData.correctedText}
                </div>
                <div className="text-[10px] text-gray-400">
                  {alignmentData.cutSegments.length} cut segments detected
                </div>
                {alignmentData.phrasesToCut.map((phrase, index) => (
                  <div key={`${phrase}-${index}`} className="text-[10px] text-gray-400">
                    {phrase}
                  </div>
                ))}
                {alignmentData.cutSegments.map((segment, index) => (
                  <div key={`${segment.start}-${segment.end}-${index}`} className="text-[10px] text-gray-500 font-mono">
                    {formatTime(segment.start)} - {formatTime(segment.end)}
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="text-[10px] text-gray-500 bg-[#1a1a1a] p-3 rounded border border-white/5 text-center">
            No transcript yet. Run Auto-Edit to generate.
          </div>
        )}
      </div>
    </div>
  );
};

  if (isLoading) return <div className="fixed inset-0 bg-[#0a0a0a]" />;

    return (
    <main className="fixed inset-0 flex flex-col bg-[#0a0a0a] text-[#ededed] font-sans select-none overflow-hidden">
      
      {/* HEADER */}
      <header className="flex-shrink-0 h-14 flex items-center justify-between px-3 border-b border-white/5 bg-[#0a0a0a] z-50 gap-2 relative">
        <button onClick={() => router.push("/dashboard")} className="p-2 flex-shrink-0 hover:bg-white/5 rounded-lg text-gray-400 transition-colors">
          <ArrowLeft size={20} />
        </button>

        <div className="flex-1 min-w-0 overflow-x-auto scrollbar-hide flex items-center bg-[#121212] rounded-lg p-1 gap-1 border border-white/5">
          {[
            { id: "studio", label: "Studio" },
            { id: "thumbnail", label: "Thumbnail" },
            { id: "publish", label: "Publish" },
            { id: "export", label: "Export" }
          ].map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as MainTab)} className={`flex-shrink-0 px-4 py-1.5 rounded-md text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-[#4ECDC4] text-[#0a0a0a] shadow-md' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              {tab.label}
            </button>
          ))}
        </div>

        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 flex-shrink-0 hover:bg-white/5 rounded-lg text-gray-400 transition-colors">
          <Menu size={20} />
        </button>

        {isMenuOpen && (
          <div className="absolute top-14 right-2 w-48 bg-[#121212] border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden">
            <button onClick={saveLayout} className="w-full text-left px-4 py-3 text-sm text-gray-300 hover:bg-[#4ECDC4]/10 flex items-center gap-3 border-b border-white/5"><Save size={16} /> Save Layout</button>
            <button onClick={resetLayout} className="w-full text-left px-4 py-3 text-sm text-gray-300 hover:bg-red-500/10 flex items-center gap-3"><RotateCcw size={16} /> Reset Layout</button>
          </div>
        )}
      </header>

      {/* MAIN CONTENT AREA */}
      {!videoUrl && activeTab === "studio" ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
           <Upload size={40} className="text-[#4ECDC4] mb-4" />
           <input type="file" accept="video/*" className="hidden" ref={fileInputRef} onChange={(e) => {
             const file = e.target.files?.[0]; if(file && draftId) { saveVideoToOPFS(draftId, file).then(() => setVideoUrl(URL.createObjectURL(file))); }
           }} />
           <button onClick={() => fileInputRef.current?.click()} className="py-3 px-6 rounded bg-[#4ECDC4] text-black font-bold text-sm">Import Media</button>
        </div>
      ) : activeTab === "studio" ? (
        <div className="flex-1 flex overflow-hidden relative">
          <div className="flex-1 flex flex-col min-w-0 bg-[#0f0f0f] relative">
            
            {/* Format Toolbar */}
            <div className="h-10 bg-[#0a0a0a] border-b border-white/5 flex items-center justify-between px-2 gap-2">
               <div className="flex items-center gap-2 flex-shrink-0">
                 {/* Format Dropdown */}
                 <div className="relative">
                   <button onClick={() => setIsFormatMenuOpen(!isFormatMenuOpen)} className="flex items-center gap-1.5 px-3 py-1 bg-[#1a1a1a] text-[#4ECDC4] border border-[#4ECDC4]/30 rounded text-xs font-bold">
                     {format} <ChevronDown size={14} className={`transition-transform ${isFormatMenuOpen ? 'rotate-180' : ''}`} />
                   </button>
                   {isFormatMenuOpen && (
                     <div className="absolute top-full left-0 mt-1 w-24 bg-[#121212] border border-white/10 rounded-lg shadow-xl z-[100] flex flex-col overflow-hidden">
                       {["9:16", "16:9", "1:1", "4:5", "21:9"].map((f) => (
                         <button key={f} onClick={() => { setFormat(f as AspectFormat); setIsFormatMenuOpen(false); }} className={`px-3 py-2 text-xs text-left hover:bg-[#4ECDC4]/20 transition-colors ${format === f ? 'text-[#4ECDC4] font-bold bg-[#4ECDC4]/10' : 'text-gray-300'}`}>{f}</button>
                       ))}
                     </div>
                   )}
                 </div>

                 {/* Zoom Controls */}
                 <div className="flex items-center bg-[#1a1a1a] rounded-lg border border-white/10 flex-shrink-0">
                   <button onClick={() => setPreviewZoom(z => Math.max(1, z - 0.1))} className="p-1.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-l-lg transition-colors"><Minus size={14}/></button>
                   <span className="text-[10px] font-mono w-8 text-center text-gray-300">{(previewZoom * 100).toFixed(0)}%</span>
                   <button onClick={() => setPreviewZoom(z => Math.min(3, z + 0.1))} className="p-1.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-r-lg transition-colors"><Plus size={14}/></button>
                 </div>
               </div>

               <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
                  <button onClick={() => setIsGridVisible(!isGridVisible)} className={`p-1 px-2 rounded text-[10px] font-bold transition-colors ${isGridVisible ? 'bg-[#4ECDC4] text-black' : 'bg-[#1a1a1a] text-gray-400 hover:text-white'}`}>Grid</button>
                  <button onClick={() => setIsFill(!isFill)} className="text-[10px] font-bold text-gray-400 hover:text-white px-1"><Maximize size={12} className="inline sm:mr-1"/><span className="hidden sm:inline">{isFill ? "Fill" : "Fit"}</span></button>
                  <button onClick={() => setIsFullscreen(true)} className="text-gray-400 hover:text-white p-1"><Maximize2 size={16}/></button>
               </div>
            </div>

            {/* Video Preview Area */}
            <div className="flex-1 relative overflow-hidden bg-[#121212] flex items-center justify-center p-4">
               <div ref={videoContainerRef} className={`relative bg-black shadow-2xl overflow-hidden flex items-center justify-center border-2 border-[#4ECDC4]/50 rounded-sm ${getAspectClass()}`}>
                 <div 
                   className="w-full h-full relative overflow-hidden transition-transform duration-75"
                   style={{ 
                     transform: `scale(${previewZoom})`,
                     clipPath: shapeMask === 'circle' ? `circle(${circleSize}% at ${maskX}% ${maskY}%)` : shapeMask === 'rectangle' ? `inset(${rectInset}% ${rectInset}% ${rectInset}% ${rectInset}%)` : 'none',
                     maskImage: gradientMask === 'fadeLeft' ? `linear-gradient(to right, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeRight' ? `linear-gradient(to left, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeUp' ? `linear-gradient(to top, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeDown' ? `linear-gradient(to bottom, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeCenter' ? `radial-gradient(circle, black ${gradientIntensity}%, transparent 100%)` : 'none',
                     WebkitMaskImage: gradientMask === 'fadeLeft' ? `linear-gradient(to right, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeRight' ? `linear-gradient(to left, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeUp' ? `linear-gradient(to top, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeDown' ? `linear-gradient(to bottom, transparent, black ${gradientIntensity}%)` : gradientMask === 'fadeCenter' ? `radial-gradient(circle, black ${gradientIntensity}%, transparent 100%)` : 'none'
                   }}
                 >
                   {activeImageClips
                     .filter((imageClip) => imageClip.layout === "background")
                     .map(renderImageClip)}

                   {splitLayout === 'single' ? (
                     <div className="relative z-10 flex h-full w-full items-center justify-center">
                       <video ref={videoRef} src={videoUrl || ""} onLoadedMetadata={onVideoLoaded} onTimeUpdate={handleTimeUpdate} onEnded={() => { setIsPlaying(false); setCurrentTime(timelineDuration); }} className={`relative z-10 w-full h-full ${isFill ? 'object-cover' : 'object-contain'} ${cutoutEnabled && cutoutEngine === "rvm" && rvm.status === "ready" ? 'opacity-0' : 'opacity-100'}`} />
                     </div>
                   ) : splitLayout === 'vertical' ? (
                     <div className="w-full h-full flex relative bg-black overflow-hidden">
                       {/* Blur Background Video */}
                       <video src={videoUrl || ""} className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-60 scale-110 pointer-events-none" muted />
                       
                       {/* Left Video */}
                       <div style={{ width: `${splitRatio}%`, maskImage: 'linear-gradient(to right, black 80%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to right, black 80%, transparent 100%)' }} className="h-full relative z-10">
                         <video ref={videoRef} src={videoUrl || ""} onLoadedMetadata={onVideoLoaded} onTimeUpdate={handleTimeUpdate} onEnded={() => { setIsPlaying(false); setCurrentTime(timelineDuration); }} className={`w-full h-full ${isFill ? 'object-cover' : 'object-contain'} ${cutoutEnabled && cutoutEngine === "rvm" && rvm.status === "ready" ? 'opacity-0' : 'opacity-100'}`} />
                       </div>
                       
                       {/* Right Video Placeholder */}
                       <div style={{ width: `${100 - splitRatio}%`, maskImage: 'linear-gradient(to left, black 80%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to left, black 80%, transparent 100%)' }} className="h-full relative z-10 flex flex-col items-center justify-center bg-black/50">
                         <Plus size={24} className="text-gray-300 mb-2" />
                         <span className="text-[10px] text-gray-300 font-bold">Add Video 2</span>
                       </div>
                     </div>
                   ) : (
                     <div className="w-full h-full flex flex-col relative bg-black overflow-hidden">
                       {/* Blur Background Video */}
                       <video src={videoUrl || ""} className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-60 scale-110 pointer-events-none" muted />
                       
                       {/* Top Video */}
                       <div style={{ height: `${splitRatio}%`, maskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)' }} className="w-full relative z-10">
                         <video ref={videoRef} src={videoUrl || ""} onLoadedMetadata={onVideoLoaded} onTimeUpdate={handleTimeUpdate} onEnded={() => { setIsPlaying(false); setCurrentTime(timelineDuration); }} className={`w-full h-full ${isFill ? 'object-cover' : 'object-contain'} ${cutoutEnabled && cutoutEngine === "rvm" && rvm.status === "ready" ? 'opacity-0' : 'opacity-100'}`} />
                       </div>
                       
                       {/* Bottom Video Placeholder */}
                       <div style={{ height: `${100 - splitRatio}%`, maskImage: 'linear-gradient(to top, black 80%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to top, black 80%, transparent 100%)' }} className="w-full relative z-10 flex flex-col items-center justify-center bg-black/50">
                         <Plus size={24} className="text-gray-300 mb-2" />
                         <span className="text-[10px] text-gray-300 font-bold">Add Video 2</span>
                       </div>
                     </div>
                   )}

                   {cutoutEnabled && cutoutEngine === "rvm" && (
                     <canvas
                       ref={canvasRef}
                       className="absolute inset-0 z-20 h-full w-full pointer-events-none object-contain"
                     />
                   )}

                   {activeImageClips
                     .filter((imageClip) => imageClip.layout !== "background")
                     .map(renderImageClip)}

                   {activeTextClips.map(txt => (
                      <div key={txt.id} onMouseDown={(e) => handleTextDragStart(e, txt)} onTouchStart={(e) => handleTextDragStart(e, txt)}
                        style={{ color: txt.color, fontSize: `${txt.size}px`, left: `${txt.x}%`, top: `${txt.y}%`, transform: 'translate(-50%, -50%)', textShadow: '2px 2px 6px rgba(0,0,0,0.9)', zIndex: 20 }}
                        className={`absolute font-bold whitespace-nowrap cursor-move px-2 py-1 ${selectedClipId === txt.id ? 'ring-2 ring-[#4ECDC4] bg-black/30' : ''}`}
                      >{txt.content}</div>
                   ))}

                   {showOutOfBoundsAlert && (
                     <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-500 text-white text-[10px] font-bold px-3 py-1.5 rounded-full z-50 shadow-lg animate-pulse whitespace-nowrap">⚠️ Element video ke bahar ja raha hai!</div>
                   )}

                   {isGridVisible && (
                     <div className="absolute inset-0 pointer-events-none z-40 flex flex-col">
                       <div className="flex-1 border-b border-black/60 flex"><div className="flex-1 border-r border-black/60"></div><div className="flex-1 border-r border-black/60"></div><div className="flex-1"></div></div>
                       <div className="flex-1 border-b border-black/60 flex"><div className="flex-1 border-r border-black/60"></div><div className="flex-1 border-r border-black/60"></div><div className="flex-1"></div></div>
                       <div className="flex-1 flex"><div className="flex-1 border-r border-black/60"></div><div className="flex-1 border-r border-black/60"></div><div className="flex-1"></div></div>
                     </div>
                   )}
                 </div>
               </div>
            </div>
            
            {/* Playback Controls */}
            <div className="h-12 border-t border-white/5 flex items-center justify-between px-2 sm:px-4 bg-[#0a0a0a]">
              <span className="text-[11px] font-mono text-[#4ECDC4] w-14 sm:w-16">{formatTime(currentTime)}</span>
              <div className="flex items-center gap-1.5 sm:gap-3">
                 <button onClick={() => seekTime(-1)} className="p-1.5 sm:p-2 bg-white/5 rounded-full hover:bg-white/10"><ChevronsLeft size={16} className="text-gray-400"/></button>
                 <button onClick={() => stepFrame("backward")} className="p-1.5 sm:p-2 bg-white/5 rounded-full hover:bg-white/10"><ChevronLeft size={18} className="text-gray-300"/></button>
                 <button onClick={togglePlay} className="p-2.5 sm:p-3 bg-white text-black rounded-full hover:scale-105 transition shadow-lg">{isPlaying ? <Pause size={18} className="fill-black" /> : <Play size={18} className="ml-0.5 fill-black" />}</button>
                 <button onClick={() => stepFrame("forward")} className="p-1.5 sm:p-2 bg-white/5 rounded-full hover:bg-white/10"><ChevronRight size={18} className="text-gray-300"/></button>
                 <button onClick={() => seekTime(1)} className="p-1.5 sm:p-2 bg-white/5 rounded-full hover:bg-white/10"><ChevronsRight size={16} className="text-gray-400"/></button>
              </div>
              <span className="text-[11px] font-mono text-gray-500 w-14 sm:w-16 text-right">{formatTime(timelineDuration)}</span>
            </div>
          </div>

          {selectedClipId && (
            <div className="hidden md:flex flex-col bg-[#121212] border-l border-white/5 relative flex-shrink-0" style={{ width: `${layout.right}px` }}>
               <div className="flex border-b border-white/5 bg-[#0a0a0a] items-center justify-between px-3 py-2">
                  <span className="text-[10px] uppercase font-bold text-gray-400">Inspector</span>
                  <button onClick={() => setSelectedClipId(null)} className="text-gray-500 hover:text-white"><X size={14}/></button>
               </div>
               <div className="p-4 flex-1 overflow-y-auto">{renderInspector()}</div>
            </div>
          )}
        </div>
      ) : activeTab === "thumbnail" ? (
         <div className="flex-1 flex items-center justify-center bg-[#050505]">
           <div className="text-center"><ImageIcon size={48} className="mx-auto text-gray-600 mb-4" /><h2 className="text-xl font-bold text-white mb-2">Thumbnail Editor</h2><p className="text-sm text-gray-400">Canvas editor coming soon.</p></div>
         </div>
      ) : activeTab === "publish" ? (
         <div className="flex-1 flex items-center justify-center bg-[#050505]">
           <div className="text-center w-full max-w-md p-6 bg-[#121212] rounded-xl border border-white/5">
             <h2 className="text-xl font-bold text-white mb-6">Publish Center</h2>
             <div className="flex gap-4 mb-6">
               <button className="flex-1 py-3 rounded-lg bg-red-500/10 text-red-500 border border-red-500/30 flex flex-col items-center gap-2"><Youtube/> YouTube</button>
               <button className="flex-1 py-3 rounded-lg bg-pink-500/10 text-pink-500 border border-pink-500/30 flex flex-col items-center gap-2"><Instagram/> Instagram</button>
             </div>
             <button className="w-full py-3 rounded-xl bg-[#4ECDC4] text-black font-bold" onClick={() => alert("Publish logic coming soon")}>Publish Now</button>
           </div>
         </div>
      ) : (
         <div className="flex-1 flex items-center justify-center bg-[#050505]">
           <div className="text-center w-full max-w-sm p-6 bg-[#121212] rounded-xl border border-white/5">
             <Download size={32} className="mx-auto text-[#4ECDC4] mb-4" />
             <h2 className="text-xl font-bold text-white mb-2">Export Video</h2>
             <button className="w-full py-3 rounded-xl bg-[#4ECDC4] text-black font-bold" onClick={() => alert("FFmpeg rendering started!")}>Render 1080p MP4</button>
           </div>
         </div>
      )}

      {/* TIMELINE */}
      {videoUrl && activeTab === "studio" && (
        <div className="flex-shrink-0 bg-[#121212] border-t border-white/10 flex flex-col relative" style={{ height: `${layout.timeline}px` }}>
          <div className="w-full h-4 bg-[#0a0a0a] flex items-center justify-center cursor-ns-resize touch-none hover:bg-[#1a1a1a] flex-shrink-0" onMouseDown={(e) => startDragLayout(e, "timeline")} onTouchStart={(e) => startDragLayout(e, "timeline")}>
            <div className="w-12 h-1 bg-white/20 rounded-full"></div>
          </div>

          <div className="h-10 bg-[#0a0a0a] border-b border-white/5 flex items-center px-3 gap-3 sm:gap-5 overflow-x-auto scrollbar-hide">
             <MousePointer2 size={16} className="text-[#4ECDC4]" />
             <Scissors onClick={splitClip} size={16} className={`${selectedClipId ? 'text-white cursor-pointer' : 'text-gray-600'}`} />
             <Trash2 onClick={deleteClip} size={16} className={`${selectedClipId ? 'text-red-400 cursor-pointer' : 'text-gray-600'}`} />
             <div className="w-[1px] h-4 bg-white/20 mx-1"></div>
             <ZoomIn size={16} className="text-gray-400 hover:text-white cursor-pointer" onClick={() => setZoom(z => Math.min(5, z + 0.5))} />
             <ZoomOut size={16} className="text-gray-400 hover:text-white cursor-pointer" onClick={() => setZoom(z => Math.max(0.5, z - 0.5))} />
             <div className="ml-auto flex items-center gap-3 flex-shrink-0">
                {selectedClipId && <button onClick={() => setIsMobilePropsOpen(true)} className="md:hidden flex items-center gap-1 px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded border border-purple-500/30"><Settings2 size={12}/> Edit</button>}

                <button onClick={async () => { 
  setIsAutoEditing(true); 
  setAutoEditStep(1); 
  setAutoEditLog(["Starting Auto-Edit Engine..."]);
  
  // Step 1: FFmpeg Audio Extract
  const ffmpegResult = await extractAudioWithFFmpeg(silenceThreshold);
  
  if (ffmpegResult) {
    setAutoEditStep(2);
    setAutoEditLog(prev => [...prev, "Audio ready. Connecting to Whisper API..."]);
    
    // Step 2: Real Whisper API Call
    const transcript = await transcribeAudio(ffmpegResult.audioBlob);
    
    if (transcript) {
      setAutoEditStep(3);
      setWhisperData(transcript);
      setAlignmentData(null);
      setAutoEditLog(prev => [...prev, "Whisper API Successful!"]);
      const alignedData = await alignScriptWithTranscript(transcript);
      if (alignedData) {
        setAlignmentData(alignedData);
        const combinedCuts = [
          ...(alignedData.cutSegments ?? []),
          ...ffmpegResult.silenceSegments,
        ]
          .filter(
            (cut) =>
              Number.isFinite(cut.start) &&
              Number.isFinite(cut.end) &&
              cut.end > cut.start,
          )
          .sort((a, b) => a.start - b.start);
        const mergedCuts: AlignmentCutSegment[] = [];
        for (const cut of combinedCuts) {
          const currentCut = mergedCuts[mergedCuts.length - 1];
          if (currentCut && cut.start <= currentCut.end + 0.1) {
            currentCut.end = Math.max(currentCut.end, cut.end);
          } else {
            mergedCuts.push({ start: cut.start, end: cut.end });
          }
        }

        setAutoEditStep(4);
        setAutoEditLog(prev => [
          ...prev,
          "Corrected text generated.",
          `Merged ${mergedCuts.length} cuts (retakes + silences).`,
          "Applying cuts to timeline...",
        ]);

        if (mergedCuts.length > 0) {
          const appliedCuts = applyAlignmentCuts(mergedCuts);
          if (appliedCuts > 0) {
            setHasAppliedCuts(true);
          }
          setAutoEditLog(prev => [
            ...prev,
            appliedCuts > 0
              ? `Cuts applied successfully (${appliedCuts} segment${appliedCuts === 1 ? "" : "s"}).`
              : "No merged cuts overlapped the current video timeline.",
            ...(appliedCuts > 0
              ? ["✅ Cuts applied! Review timeline and click Magic Edit."]
              : []),
          ]);
        }
        setAutoEditStep(8);
        setAutoEditLog(prev => [...prev, "Auto-Edit Completed Successfully!"]);
      } else {
        setAutoEditStep(0);
        setAutoEditLog(prev => [...prev, "Auto-Edit incomplete. Alignment did not complete."]);
      }
    } else {
      setAutoEditLog(prev => [...prev, "Whisper API Failed. Check F12 console."]);
      setAutoEditStep(0);
    }
  } else {
    setAutoEditLog(prev => [...prev, "Audio extract failed. Check F12 console."]);
    setAutoEditStep(0);
  }
}} className="flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold rounded shadow-md hover:opacity-90">
  <Sparkles size={14}/> Auto-Edit
</button>

                {hasAppliedCuts && (
                  <button
                    onClick={runMagicEdit}
                    disabled={isAutoEditing}
                    className="flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-blue-500 to-cyan-500 text-white text-xs font-bold rounded shadow-md hover:opacity-90 animate-in fade-in zoom-in"
                  >
                    <Wand2 size={14} /> Magic Edit (B-Roll)
                  </button>
                )}

                <button onClick={() => { setActiveTool("menu"); setIsToolsOpen(true); }} className="flex items-center gap-1 px-3 py-1 bg-[#1a1a1a] text-[#4ECDC4] text-xs rounded border border-[#4ECDC4]/30"><Wrench size={14}/> Tools</button>
             </div>
          </div>

          <div className="flex-1 flex overflow-hidden bg-[#161616]" onTouchStart={handleTouchStart} onTouchMove={handleTouchMove}>
             <div className="w-12 flex-shrink-0 bg-[#0a0a0a] border-r border-white/10 z-40 flex flex-col pt-1">
                <div className="h-[28px] w-full border-b border-transparent"></div>
                {TRACKS.map(t => {
                  const trackId = t.toLowerCase();
                  const isLocked = lockedTracks.includes(trackId);
                  return (
                    <div key={t} onClick={() => setLockedTracks(prev => isLocked ? prev.filter(id => id !== trackId) : [...prev, trackId])} className={`flex-1 min-h-[24px] flex items-center justify-between px-1 text-[10px] font-bold border-b border-white/5 cursor-pointer hover:bg-white/5 ${isLocked ? 'text-red-400 bg-red-500/10' : 'text-gray-500'}`}>
                      <span>{t}</span><span>{isLocked ? "🔒" : "🔓"}</span>
                    </div>
                  );
                })}
             </div>

             <div className="flex-1 overflow-x-auto overflow-y-hidden relative scrollbar-hide" ref={timelineRef}>
                <div style={{ width: `${100 * zoom}%`, height: "100%", minWidth: "100%" }} className="relative pt-1 flex flex-col h-full">
                  
                  <div ref={rulerRef} className="relative h-6 w-full bg-[#1a1a1a] border-b border-white/10 mb-1 cursor-pointer z-30 touch-none select-none flex-shrink-0"
                    onMouseDown={(e) => { setIsScrubbing(true); handleScrub(e.clientX); }}
                    onTouchStart={(e) => {
                      setIsScrubbing(true);
                      const touch = e.touches.item(0);
                      if (touch) handleScrub(touch.clientX);
                    }}
                    onClick={(e) => handleScrub(e.clientX)}
                  >
                    <div className="absolute inset-0 pointer-events-none">
                      {Array.from({ length: timelineDuration > 0 ? Math.ceil(timelineDuration) + 1 : 0 }).map((_, i) => {
                        const safeLeft = timelineDuration > 0 ? (i / timelineDuration) * 100 : 0;
                        const isMajor = timelineDuration <= 10 ? true : (i % 5 === 0);
                        return (
                          <div key={i} className="absolute bottom-0 flex flex-col justify-end items-start" style={{ left: `${safeLeft}%` }}>
                            {isMajor && <span className="absolute top-0.5 left-1 text-[9px] font-bold text-gray-400">{formatTime(i).substring(3)}</span>}
                            <div className={`w-px ${isMajor ? 'h-2.5 bg-gray-300' : 'h-1.5 bg-gray-600'}`} />
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div ref={playheadRef} className="absolute top-0 bottom-0 z-40 pointer-events-none" style={{ left: `${Math.min(getTimelinePercent(currentTime), 100)}%` }}>
                    <div className="absolute top-0 -translate-x-1/2 bg-[#4ECDC4] text-[#0a0a0a] text-[9px] font-extrabold px-1.5 py-0.5 rounded shadow-md whitespace-nowrap playhead-timecode border border-black/20 z-50">{formatTime(currentTime)}</div>
                    <div className="w-[2px] h-full bg-[#4ECDC4] mx-auto shadow-[0_0_8px_rgba(78,205,196,0.8)]"></div>
                  </div>

                  {TRACKS.map(track => {
                    const trackId = track.toLowerCase();
                    return (
                    <div key={trackId} className="relative flex-1 min-h-[24px] bg-[#1a1a1a] border-y border-white/5 flex items-center">
                      {clips.filter(c => c.track === trackId).map(clip => {
                         let left = 0;
                         if (clip.type === "video") {
                           let acc = 0; clips.filter(c=>c.type==="video").sort((a,b)=>a.start-b.start).forEach(c => { if (c.id === clip.id) left = acc; else acc += (c.end - c.start); });
                           left = timelineDuration > 0 ? (left / timelineDuration) * 100 : 0;
                         } else { left = timelineDuration > 0 ? (clip.start / timelineDuration) * 100 : 0; }
                         
                         const width = timelineDuration > 0 ? ((clip.end - clip.start) / timelineDuration) * 100 : 0;
                         const isSelected = selectedClipId === clip.id;
                         
                         return (
                           <div key={clip.id} onClick={(e) => { e.stopPropagation(); if (!lockedTracks.includes(trackId)) setSelectedClipId(clip.id); }}
                             className={`absolute h-full border-2 overflow-hidden flex rounded-sm cursor-pointer ${isSelected ? 'border-[#4ECDC4] z-20' : (clip.type==="video" ? 'border-green-500/50 z-10' : clip.type==="text" ? 'border-purple-500/50 bg-purple-500/20' : 'border-blue-500/50 bg-blue-500/20')}`} 
                             style={{ left: `${left}%`, width: `${width}%` }}>
                              
                              {clip.type === "video" && (
                                <div className="flex w-full h-full opacity-80 pointer-events-none overflow-hidden">
                                  {timelineFrames.map((f, i) => <img key={i} src={f || ""} alt="" className="h-full w-8 sm:w-12 flex-shrink-0 object-cover border-r border-black/30"/>)}
                                </div>
                              )}
                              {clip.type === "text" && <span className="text-[9px] text-white/90 px-2 truncate">{clip.content}</span>}
                              {clip.type === "image" && <span className="text-[9px] text-white/90 px-2 truncate">B-Roll: {clip.prompt}</span>}
                              {clip.type === "audio" && <span className="text-[9px] text-white/90 px-2 truncate">{clip.name}</span>}
                              {clip.type === "effect" && <span className="text-[9px] text-white/90 px-2 truncate">{clip.name}</span>}

                              <div onMouseDown={(e) => handleClipResizeStart(e, clip, "left")} onTouchStart={(e) => handleClipResizeStart(e, clip, "left")} className="absolute left-0 top-0 bottom-0 w-3 bg-white/30 hover:bg-[#4ECDC4] cursor-ew-resize z-30" />
                              <div onMouseDown={(e) => handleClipResizeStart(e, clip, "right")} onTouchStart={(e) => handleClipResizeStart(e, clip, "right")} className="absolute right-0 top-0 bottom-0 w-3 bg-white/30 hover:bg-[#4ECDC4] cursor-ew-resize z-30" />
                           </div>
                         )
                      })}
                    </div>
                    );
                  })}
                </div>
             </div>
          </div>
        </div>
      )}

      {/* MOBILE PROPERTIES BOTTOM SHEET */}
      <div className={`fixed inset-0 bg-black/60 z-[60] transition-opacity md:hidden ${isMobilePropsOpen && selectedClipId ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsMobilePropsOpen(false)}>
        <div className={`absolute bottom-0 inset-x-0 bg-[#121212] rounded-t-3xl border-t border-white/10 transition-transform duration-300 ${isMobilePropsOpen && selectedClipId ? 'translate-y-0' : 'translate-y-full'}`} onClick={e => e.stopPropagation()}>
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2"></div>
          <div className="flex items-center justify-between px-5 py-3 border-b border-white/5"><h3 className="text-sm font-bold text-white">Edit Clip</h3><button onClick={() => setIsMobilePropsOpen(false)} className="p-1 text-gray-400 hover:text-white"><X size={18}/></button></div>
          <div className="p-5 pb-8 max-h-[60vh] overflow-y-auto">{renderInspector()}</div>
        </div>
      </div>

      {/* TOOLS DRAWER (Menu + Settings) */}
      <div className={`fixed inset-0 bg-black/60 z-[60] transition-opacity ${isToolsOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsToolsOpen(false)}>
        <div className={`absolute bottom-0 inset-x-0 bg-[#121212] rounded-t-3xl border-t border-white/10 transition-transform duration-300 flex flex-col max-h-[75vh] ${isToolsOpen ? 'translate-y-0' : 'translate-y-full'}`} onClick={e => e.stopPropagation()}>
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mt-3 mb-2 shrink-0"></div>
          
          {/* Drawer Header */}
          <div className="flex items-center justify-between px-5 py-3 border-b border-white/5 shrink-0">
            <div className="flex items-center gap-3">
              {activeTool !== "menu" && (
                <button onClick={() => setActiveTool("menu")} className="p-1 text-gray-400 hover:text-white bg-white/5 rounded-md"><ChevronLeft size={18}/></button>
              )}
              <h3 className="text-sm font-bold text-white capitalize">{activeTool === "menu" ? "Editor Tools" : `${activeTool} Settings`}</h3>
            </div>
            <button onClick={() => setIsToolsOpen(false)} className="p-1 text-gray-400 hover:text-white"><X size={18}/></button>
          </div>

          {/* Drawer Content */}
          <div className="p-4 pb-8 overflow-y-auto flex-1">
             {activeTool === "menu" ? (
               <>
                 <div className="grid grid-cols-4 gap-2 mb-4">
                    <button onClick={() => setActiveTool("cuts")} className={`flex flex-col items-center gap-2 p-2 rounded-xl border bg-[#1a1a1a] text-gray-400 hover:text-white`}><Scissors size={20}/><span className="text-[10px]">Cuts</span></button>
                    <button onClick={() => { addClip("text"); setIsToolsOpen(false); }} className="flex flex-col items-center gap-2 p-2 rounded-xl border bg-[#1a1a1a] text-gray-400 hover:text-white"><Type size={20}/><span className="text-[10px]">Text</span></button>
                    <button onClick={() => { addClip("audio"); setIsToolsOpen(false); }} className="flex flex-col items-center gap-2 p-2 rounded-xl border bg-[#1a1a1a] text-gray-400 hover:text-white"><Music size={20}/><span className="text-[10px]">Audio</span></button>
                    <button onClick={() => setActiveTool("effects")} className={`flex flex-col items-center gap-2 p-2 rounded-xl border bg-[#1a1a1a] text-gray-400 hover:text-white`}><Sparkles size={20}/><span className="text-[10px]">Effects</span></button>
                    <button onClick={() => setActiveTool("captions")} className={`flex flex-col items-center gap-2 p-2 rounded-xl border bg-[#1a1a1a] text-gray-400 hover:text-white`}><AlignLeft size={20}/><span className="text-[10px]">Captions</span></button>
                    <button onClick={() => setActiveTool("speed")} className={`flex flex-col items-center gap-2 p-2 rounded-xl border bg-[#1a1a1a] text-gray-400 hover:text-white`}><MonitorPlay size={20}/><span className="text-[10px]">Speed</span></button>
                    <button onClick={() => setActiveTool("masking")} className={`flex flex-col items-center gap-2 p-2 rounded-xl border col-span-2 bg-[#1a1a1a] text-gray-400 hover:text-white`}><Layers size={20}/><span className="text-[10px]">Masking</span></button>
                 </div>
                 <div className="mt-4 border-t border-white/5 pt-4">
                   <div className="text-[10px] text-[#4ECDC4] font-bold uppercase mb-2">Auto-Edit Settings</div>
                   <div className="bg-[#1a1a1a] p-3 rounded border border-white/5">
                     <div className="flex justify-between text-[10px] text-gray-400 mb-2">
                       <span>Silence Threshold</span>
                       <span className="text-white font-mono">{silenceThreshold.toFixed(1)}s</span>
                     </div>
                     <input
                       type="range"
                       min="0.3"
                       max="2.0"
                       step="0.1"
                       value={silenceThreshold}
                       onChange={(e) => setSilenceThreshold(parseFloat(e.target.value))}
                       className="w-full accent-[#4ECDC4]"
                     />
                     <p className="text-[8px] text-gray-500 mt-2">Lower value = Faster cuts (0.3s recommended)</p>
                   </div>
                 </div>
               </>
             ) : activeTool === "masking" ? (
               <div className="bg-[#1a1a1a] border border-white/10 rounded-xl p-3 space-y-4">
                 <div>
                   <h4 className="text-xs font-bold text-[#4ECDC4] mb-2">Layout</h4>
                   <div className="grid grid-cols-3 gap-2">
                     <button onClick={() => setSplitLayout('single')} className={`py-2 rounded text-[10px] font-bold ${splitLayout === 'single' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Single</button>
                     <button onClick={() => setSplitLayout('vertical')} className={`py-2 rounded text-[10px] font-bold ${splitLayout === 'vertical' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Split V</button>
                     <button onClick={() => setSplitLayout('horizontal')} className={`py-2 rounded text-[10px] font-bold ${splitLayout === 'horizontal' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Split H</button>
                   </div>
                   {splitLayout !== 'single' && (
                     <div className="mt-3">
                       <div className="flex justify-between text-[9px] text-gray-400 mb-1"><span>Ratio</span><span>{splitRatio}% / {100-splitRatio}%</span></div>
                       <input type="range" min="20" max="80" value={splitRatio} onChange={(e) => setSplitRatio(parseInt(e.target.value))} className="w-full accent-[#4ECDC4]" />
                     </div>
                   )}
                 </div>
                 <div>
                   <h4 className="text-xs font-bold text-[#4ECDC4] mb-2">Shape</h4>
                   <div className="grid grid-cols-3 gap-2">
                     <button onClick={() => setShapeMask('none')} className={`py-2 rounded text-[10px] font-bold ${shapeMask === 'none' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>None</button>
                     <button onClick={() => setShapeMask('circle')} className={`py-2 rounded text-[10px] font-bold ${shapeMask === 'circle' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Circle</button>
                     <button onClick={() => setShapeMask('rectangle')} className={`py-2 rounded text-[10px] font-bold ${shapeMask === 'rectangle' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Rect</button>
                   </div>
                   {shapeMask === 'circle' && (
                     <div className="mt-3 space-y-2">
                       <div>
                         <div className="flex justify-between text-[9px] text-gray-400 mb-1"><span>Circle Size</span><span>{circleSize}%</span></div>
                         <input type="range" min="10" max="90" value={circleSize} onChange={(e) => setCircleSize(parseInt(e.target.value))} className="w-full accent-[#4ECDC4]" />
                       </div>
                       <div>
                         <div className="flex justify-between text-[9px] text-gray-400 mb-1"><span>Position X</span><span>{maskX}%</span></div>
                         <input type="range" min="0" max="100" value={maskX} onChange={(e) => setMaskX(parseInt(e.target.value))} className="w-full accent-[#4ECDC4]" />
                       </div>
                       <div>
                         <div className="flex justify-between text-[9px] text-gray-400 mb-1"><span>Position Y</span><span>{maskY}%</span></div>
                         <input type="range" min="0" max="100" value={maskY} onChange={(e) => setMaskY(parseInt(e.target.value))} className="w-full accent-[#4ECDC4]" />
                       </div>
                     </div>
                   )}
                   {shapeMask === 'rectangle' && (
                     <div className="mt-3">
                       <div className="flex justify-between text-[9px] text-gray-400 mb-1"><span>Inset</span><span>{rectInset}%</span></div>
                       <input type="range" min="0" max="40" value={rectInset} onChange={(e) => setRectInset(parseInt(e.target.value))} className="w-full accent-[#4ECDC4]" />
                     </div>
                   )}
                 </div>
                 <div>
                   <h4 className="text-xs font-bold text-[#4ECDC4] mb-2">Gradient</h4>
                   <div className="grid grid-cols-3 gap-2">
                     <button onClick={() => setGradientMask('none')} className={`py-2 rounded text-[10px] font-bold ${gradientMask === 'none' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>None</button>
                     <button onClick={() => setGradientMask('fadeLeft')} className={`py-2 rounded text-[10px] font-bold ${gradientMask === 'fadeLeft' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Fade L</button>
                     <button onClick={() => setGradientMask('fadeRight')} className={`py-2 rounded text-[10px] font-bold ${gradientMask === 'fadeRight' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Fade R</button>
                     <button onClick={() => setGradientMask('fadeUp')} className={`py-2 rounded text-[10px] font-bold ${gradientMask === 'fadeUp' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Fade U</button>
                     <button onClick={() => setGradientMask('fadeDown')} className={`py-2 rounded text-[10px] font-bold ${gradientMask === 'fadeDown' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Fade D</button>
                     <button onClick={() => setGradientMask('fadeCenter')} className={`py-2 rounded text-[10px] font-bold ${gradientMask === 'fadeCenter' ? 'bg-[#4ECDC4] text-black' : 'bg-black/50 text-gray-400'}`}>Center</button>
                   </div>
                   {gradientMask !== 'none' && (
                     <div className="mt-3">
                       <div className="flex justify-between text-[9px] text-gray-400 mb-1"><span>Intensity</span><span>{gradientIntensity}%</span></div>
                       <input type="range" min="10" max="90" value={gradientIntensity} onChange={(e) => setGradientIntensity(parseInt(e.target.value))} className="w-full accent-[#4ECDC4]" />
                     </div>
                   )}
                 </div>
               </div>
             ) : (
               <div className="text-center text-gray-500 text-xs py-10">
                 {activeTool} settings coming soon...
               </div>
             )}
          </div>
        </div>
      </div>

{/* AUTO EDIT PROGRESS MODAL */}
{isAutoEditing && (
  <div className="fixed inset-0 bg-black/90 z-[100] flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-2xl relative">
            
                  <div className="flex flex-col items-center mb-6">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                                     <Sparkles size={24} className="text-white" />
                                             </div>
                                                     <h3 className="text-lg font-bold text-white">AI Director at Work</h3>
                                                             <p className="text-xs text-gray-400 mt-1">Step {Math.min(autoEditStep, 7)} of 7</p>
                                                                   </div>

                                                                         {/* Progress Bar */}
                                                                               <div className="w-full h-2 bg-[#1a1a1a] rounded-full mb-6 overflow-hidden">
                                                                                       <div 
                                                                                                 className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500" 
                                                                                                           style={{ width: `${(Math.min(autoEditStep, 8) / 8) * 100}%` }}
                                                                                                                   ></div>
                                                                                                                         </div>

                                                                                                                               {/* Logs */}
                                                                                                                                     <div className="bg-[#0a0a0a] border border-white/5 rounded-lg p-3 h-32 overflow-y-auto mb-6 flex flex-col gap-2">
                                                                                                                                             {autoEditLog.map((log, i) => (
                                                                                                                                                       <div key={i} className="flex items-start gap-2 text-xs">
                                                                                                                                                                   <CheckCircle2 size={12} className="text-[#4ECDC4] mt-0.5 flex-shrink-0" />
                                                                                                                                                                               <span className="text-gray-300">{log}</span>
                                                                                                                                                                                         </div>
                                                                                                                                                                                                 ))}
                                                                                                                                                                                                       </div>

                                                                                                                                                                                                             {/* Action Buttons */}
                                                                                                                                                                                                                   {autoEditStep === 8 ? (
                                                                                                                                                                                                                           <button onClick={() => setIsAutoEditing(false)} className="w-full py-3 rounded-xl bg-[#4ECDC4] text-black font-bold text-sm hover:bg-emerald-400 transition">
                                                                                                                                                                                                                                     Review Cuts on Timeline
                                                                                                                                                                                                                                             </button>
                                                                                                                                                                                                                                                   ) : (
                                                                                                                                                                                                                                                           <button onClick={() => { setIsAutoEditing(false); setAutoEditStep(0); }} className="w-full py-3 rounded-xl bg-red-500/10 text-red-400 font-bold text-sm hover:bg-red-500/20 transition">
                                                                                                                                                                                                                                                                     Cancel Auto-Edit
                                                                                                                                                                                                                                                                             </button>
                                                                                                                                                                                                                                                                                   )}

                                                                                                                                                                                                                                                                                       </div>
                                                                                                                                                                                                                                                                                         </div>
                                                                                                                                                                                                                                                                                         )}
                                                                                                                                                                                                                                                                                         
      {/* FULLSCREEN VIDEO */}
      {isFullscreen && (
        <div className="fixed inset-0 bg-black z-[100] flex items-center justify-center">
          <button onClick={() => setIsFullscreen(false)} className="absolute top-4 right-4 z-[110] p-2 bg-black/60 rounded-full text-white hover:bg-white/20"><X size={24} /></button>
          <video src={videoUrl || ""} controls autoPlay className={`w-full h-full ${isFill ? 'object-cover' : 'object-contain'}`} />
        </div>
      )}
    </main>
  );
}