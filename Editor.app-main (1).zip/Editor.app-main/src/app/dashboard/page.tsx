"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { onAuthStateChanged, signOut, User } from "firebase/auth";
import { auth, db } from "@/lib/firebase/client";
import { collection, query, where, getDocs, doc, setDoc, deleteDoc } from "firebase/firestore";
import { Plus, LogOut, Search, Video, FolderOpen, Play, FileJson, Trash2, Circle, CheckCircle2 } from "lucide-react";

type Draft = { id: string; topic: string; brandName: string; status: string; createdAt: number; };

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [showNewOptions, setShowNewOptions] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (!currentUser) router.push("/");
      else { setUser(currentUser); fetchDrafts(currentUser.uid); }
    });
    return () => unsubscribe();
  }, [router]);

  const fetchDrafts = async (uid: string) => {
    try {
      const q = query(collection(db, "drafts"), where("createdBy", "==", uid));
      const snap = await getDocs(q);
      const fetched: Draft[] = [];
      snap.forEach((doc) => fetched.push(doc.data() as Draft));
      fetched.sort((a, b) => b.createdAt - a.createdAt);
      setDrafts(fetched);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const handleCreateBlankDraft = async () => {
    if (!user) return;
    setIsCreating(true);
    try {
      const draftId = crypto.randomUUID();
      await setDoc(doc(db, "drafts", draftId), {
        id: draftId, brandName: "Manual Draft", topic: "Untitled Video",
        createdBy: user.uid, createdAt: Date.now(), status: "in_progress"
      });
      router.push(`/studio?id=${draftId}&topic=Untitled%20Video`);
    } catch (e) { console.error(e); setIsCreating(false); }
  };

  const toggleSelectionMode = () => {
    setIsSelectionMode(!isSelectionMode);
    setSelectedIds([]);
  };

  const handleSelectDraft = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleDeleteSelected = async () => {
    if (selectedIds.length === 0 || !window.confirm(`Delete ${selectedIds.length} draft(s)?`)) return;
    try {
      for (const id of selectedIds) await deleteDoc(doc(db, "drafts", id));
      setDrafts(drafts.filter(d => !selectedIds.includes(d.id)));
      setSelectedIds([]); setIsSelectionMode(false);
    } catch { alert("Failed to delete."); }
  };

  if (loading) return <div className="fixed inset-0 flex items-center justify-center bg-[#0a0a0a]"><div className="w-8 h-8 border-4 border-[#4ECDC4] border-t-transparent rounded-full animate-spin"></div></div>;

  return (
    <main className="fixed inset-0 flex flex-col bg-[#0a0a0a] text-white">
      <header className="flex-shrink-0 flex items-center justify-between px-5 py-4 border-b border-white/5 bg-[#0a0a0a] z-20">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#4ECDC4] flex items-center justify-center"><Video size={18} className="text-[#0a0a0a]" /></div>
          <div>
            <h1 className="text-sm font-bold leading-tight">Mothers Inside</h1>
            <p className="text-[10px] text-gray-400 leading-tight">CreatorOS Edit</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {/* SELECT BUTTON YAHAN HAI */}
          {drafts.length > 0 && (
            <button onClick={toggleSelectionMode} className={`text-sm font-semibold px-2 py-1 ${isSelectionMode ? 'text-red-400' : 'text-[#4ECDC4]'}`}>
              {isSelectionMode ? "Cancel" : "Select"}
            </button>
          )}
          <button onClick={async () => { await signOut(auth); router.push("/"); }} className="p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10">
            <LogOut size={16} />
          </button>
        </div>
      </header>

      {!isSelectionMode && (
        <div className="flex-shrink-0 px-5 pt-4 pb-3">
          <div className="relative mb-4">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input type="text" placeholder="Search drafts..." className="w-full pl-9 pr-4 py-2.5 bg-[#121212] border border-white/5 rounded-xl text-sm focus:border-[#4ECDC4] focus:outline-none" />
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-5 pb-24 pt-2">
        {drafts.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center mt-10">
            <FolderOpen size={48} className="text-gray-600 mb-4" />
            <h2 className="text-lg font-bold mb-6">No drafts yet</h2>
            <div className="flex flex-col w-full gap-2 px-6">
              <button onClick={() => router.push("/import")} className="w-full py-3 rounded-xl bg-[#121212] border border-[#4ECDC4]/30 text-[#4ECDC4] text-sm font-semibold">Import Handoff JSON</button>
              <button onClick={handleCreateBlankDraft} disabled={isCreating} className="w-full py-3 rounded-xl bg-[#4ECDC4] text-black text-sm font-bold disabled:opacity-50">{isCreating ? "Creating..." : "Start Blank Draft"}</button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {drafts.map((draft) => {
              const isSelected = selectedIds.includes(draft.id);
              return (
                <div key={draft.id} 
                  onClick={(e) => isSelectionMode ? handleSelectDraft(e, draft.id) : router.push(`/studio?id=${draft.id}&topic=${encodeURIComponent(draft.topic)}`)}
                  className={`bg-[#121212] border ${isSelected ? 'border-[#4ECDC4]' : 'border-white/5'} rounded-2xl p-4 flex gap-4 cursor-pointer relative`}
                >
                  <div className="w-20 h-20 bg-[#1a1a1a] rounded-xl flex items-center justify-center"><Play size={20} className="text-gray-600" /></div>
                  <div className="flex flex-col justify-center min-w-0 pr-6">
                    <h3 className="text-sm font-bold truncate">{draft.topic}</h3>
                    <p className="text-[11px] text-gray-500 truncate mt-0.5">{draft.brandName}</p>
                  </div>
                  {isSelectionMode && (
                    <div className="absolute right-4 top-1/2 -translate-y-1/2">
                      {isSelected ? <CheckCircle2 className="text-[#4ECDC4]" size={22} /> : <Circle className="text-gray-600" size={22} />}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {!isSelectionMode && (
        <button onClick={() => setShowNewOptions(true)} className="absolute bottom-6 right-6 w-14 h-14 bg-[#4ECDC4] text-black rounded-full shadow-lg flex items-center justify-center">
          <Plus size={24} />
        </button>
      )}

      {isSelectionMode && (
        <div className="absolute bottom-0 inset-x-0 bg-[#121212] border-t border-white/10 p-4 pb-6 z-30 flex justify-between items-center">
          <p className="text-sm font-medium">{selectedIds.length} selected</p>
          <button onClick={handleDeleteSelected} disabled={selectedIds.length === 0} className="px-5 py-2.5 rounded-xl bg-red-500/10 text-red-500 border border-red-500/20 flex items-center gap-2 disabled:opacity-50">
            <Trash2 size={16} /> Delete
          </button>
        </div>
      )}

      {/* Modal for New Draft (Simplified) */}
      {showNewOptions && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60" onClick={() => setShowNewOptions(false)}>
          <div className="bg-[#121212] p-5 rounded-t-3xl border-t border-white/10" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4 text-center">Create New</h3>
            <button onClick={() => router.push("/import")} className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-[#0a0a0a] mb-2 border border-white/5">
               <FileJson size={20} className="text-[#4ECDC4]" /> Import Handoff JSON
            </button>
            <button onClick={handleCreateBlankDraft} disabled={isCreating} className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-[#0a0a0a] border border-white/5 disabled:opacity-50">
               <Video size={20} className="text-emerald-400" /> {isCreating ? "Creating..." : "Start Blank Draft"}
            </button>
            <button onClick={() => setShowNewOptions(false)} className="w-full mt-4 py-3 text-sm text-gray-400">Cancel</button>
          </div>
        </div>
      )}
    </main>
  );
}