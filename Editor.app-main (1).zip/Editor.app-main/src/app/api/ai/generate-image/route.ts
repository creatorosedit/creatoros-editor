import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
      const { prompt, width = 1024, height = 1024 } = await req.json();

          if (!prompt) {
                return NextResponse.json({ success: false, error: 'Missing prompt' }, { status: 400 });
                    }

                        const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
                            const apiToken = process.env.CLOUDFLARE_API_TOKEN;

                                if (!accountId || !apiToken) {
                                      return NextResponse.json({ success: false, error: 'Cloudflare credentials missing' }, { status: 500 });
                                          }

                                              const response = await fetch(
                                                    `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/@cf/black-forest-labs/flux-1-schnell`,
                                                          {
                                                                  method: 'POST',
                                                                          headers: {
                                                                                    'Authorization': `Bearer ${apiToken}`,
                                                                                              'Content-Type': 'application/json',
                                                                                                      },
                                                                                                              body: JSON.stringify({
                                                                                                                        prompt,
                                                                                                                        steps: 4, // 4 is default, max is 8
                                                                                                                        width: width,
                                                                                                                        height: height,
                                                                                                              }),
                                                                                                                                                }
                                                                                                                                                    );

                                                                                                                                                        const result = await response.json();

                                                                                                                                                            if (!result.success) {
                                                                                                                                                                  throw new Error(result.errors?.[0]?.message || 'Image generation failed');
                                                                                                                                                                      }

                                                                                                                                                                          // Cloudflare returns the image as a base64 string
                                                                                                                                                                              const base64Image = result.result.image;

                                                                                                                                                                                  return NextResponse.json({ success: true, image: base64Image });
                                                                                                                                                                                    } catch (error: unknown) {
                                                                                                                                                                                        console.error("Cloudflare Image API Error:", error);
                                                                                                                                                                                            const message = error instanceof Error ? error.message : "Image generation failed";
                                                                                                                                                                                            return NextResponse.json({ success: false, error: message }, { status: 500 });
                                                                                                                                                                                              }
                                                                                                                                                                                              }