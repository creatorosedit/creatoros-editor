import { NextRequest, NextResponse } from 'next/server';
import Groq from 'groq-sdk';

export async function POST(req: NextRequest) {
  try {
      if (!process.env.GROQ_API_KEY_EDIT) {
            return NextResponse.json({ success: false, error: 'GROQ_API_KEY_EDIT missing in .env.local' }, { status: 500 });
                }

                    const formData = await req.formData();
                        const audioFile = formData.get('audio') as File;
                            
                                if (!audioFile) {
                                      return NextResponse.json({ success: false, error: 'No audio provided' }, { status: 400 });
                                          }

                                              const groq = new Groq({ apiKey: process.env.GROQ_API_KEY_EDIT });

                                                  const transcription = await groq.audio.transcriptions.create({
                                                        file: audioFile,
                                                              model: 'whisper-large-v3',
                                                                    language: 'hi', // Hinglish ke liye
                                                                          response_format: 'verbose_json',
                                                                                timestamp_granularities: ['word'],
                                                                                    });

                                                                                        return NextResponse.json({ success: true, data: transcription });
                                                                                          } catch (error: unknown) {
                                                                                              console.error("Whisper API Error:", error);
                                                                                                  const message = error instanceof Error ? error.message : "Unknown Whisper API error";
                                                                                                  return NextResponse.json({ success: false, error: message }, { status: 500 });
                                                                                                    }
                                                                                                    }