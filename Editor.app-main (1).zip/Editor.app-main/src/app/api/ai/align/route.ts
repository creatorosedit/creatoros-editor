import { NextRequest, NextResponse } from "next/server";
import Groq from "groq-sdk";
import { z } from "zod";

const AlignmentRequestSchema = z.object({
  script: z.string().trim().min(1),
  transcriptText: z.string().trim().min(1),
  transcriptWords: z
    .array(
      z.object({
        word: z.string(),
        start: z.number().finite().nonnegative(),
        end: z.number().finite().nonnegative(),
      }).refine((word) => word.end >= word.start),
    )
    .optional(),
});

const AlignmentResponseSchema = z.object({
  correctedText: z.string().optional(),
  phrasesToCut: z.array(z.string()).optional(),
});

const normalizeWord = (word: string) =>
  word.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");

export async function POST(req: NextRequest) {
  if (!process.env.GROQ_API_KEY_EDIT) {
    return NextResponse.json(
      { success: false, error: "GROQ_API_KEY_EDIT missing" },
      { status: 500 },
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { success: false, error: "Request body must be valid JSON" },
      { status: 400 },
    );
  }

  const parsedRequest = AlignmentRequestSchema.safeParse(body);
  if (!parsedRequest.success) {
    return NextResponse.json(
      { success: false, error: "A script and transcript are required" },
      { status: 400 },
    );
  }

  const { script, transcriptText, transcriptWords } = parsedRequest.data;

  try {
    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY_EDIT });
    const request = {
      messages: [
        {
          role: "system" as const,
          content:
            "You are an expert video editor. Compare the original script with a raw speech transcript that may contain typos, retakes, stutters, and filler words. Identify exact phrases in the transcript that should be cut, and return corrected text using the original script as reference. Return only a JSON object with correctedText (string) and phrasesToCut (array of exact transcript phrases). Do not use Markdown or wrap the JSON in a code fence.",
        },
        {
          role: "user" as const,
          content: JSON.stringify({ originalScript: script, rawTranscript: transcriptText }),
        },
      ],
      temperature: 0.1,
    };
    let response;
    try {
      response = await groq.chat.completions.create({
        ...request,
        model: "openai/gpt-oss-120b",
      });
    } catch {
      response = await groq.chat.completions.create({
        ...request,
        model: "openai/gpt-oss-20b",
      });
    }

    const content = response.choices[0]?.message?.content || "";
    if (!content.trim()) {
      throw new Error("AI alignment returned an empty response");
    }

    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("AI alignment did not return a JSON object");
    }

    const aiResult: unknown = JSON.parse(jsonMatch[0]);
    const parsedResponse = AlignmentResponseSchema.safeParse(aiResult);
    if (!parsedResponse.success) {
      throw new Error("AI alignment returned an invalid response");
    }

    const phrasesToCut = parsedResponse.data.phrasesToCut ?? [];
    const cutSegments: { start: number; end: number }[] = [];

    if (transcriptWords) {
      for (const phrase of phrasesToCut) {
        const phraseWords = phrase.split(/\s+/u).map(normalizeWord).filter(Boolean);
        if (phraseWords.length === 0) continue;

        for (let startIndex = 0; startIndex <= transcriptWords.length - phraseWords.length; startIndex++) {
          const matches = phraseWords.every(
            (word, offset) => {
              const transcriptWord = transcriptWords[startIndex + offset];
              return transcriptWord !== undefined && normalizeWord(transcriptWord.word) === word;
            },
          );
          if (!matches) continue;

          const firstWord = transcriptWords[startIndex];
          const lastWord = transcriptWords[startIndex + phraseWords.length - 1];
          if (firstWord && lastWord) {
            cutSegments.push({ start: firstWord.start, end: lastWord.end });
          }
          break;
        }
      }
    }

    cutSegments.sort((a, b) => a.start - b.start);

    return NextResponse.json({
      success: true,
      data: {
        correctedText: parsedResponse.data.correctedText ?? transcriptText,
        cutSegments,
        phrasesToCut,
      },
    });
  } catch (error: unknown) {
    console.error("Alignment API Error:", error);
    let errMsg: string;
    if (typeof error === "string") {
      errMsg = error;
    } else if (error instanceof Error) {
      errMsg = error.message;
    } else {
      try {
        errMsg = JSON.stringify(error) ?? String(error);
      } catch {
        errMsg = String(error);
      }
    }
    return NextResponse.json({ success: false, error: errMsg }, { status: 500 });
  }
}
