import { NextRequest, NextResponse } from 'next/server';
import Groq from 'groq-sdk';
import { z } from 'zod';

const VisualSchema = z.object({
  prompt: z.string(),
  startTime: z.number(),
  endTime: z.number(),
  layout: z.enum(["full", "half_top", "half_bottom", "half_left", "half_right", "overlay", "background"]),
});

const MagicEditResponseSchema = z.object({
  visuals: z.array(VisualSchema),
});

export async function POST(req: NextRequest) {
  try {
    if (!process.env.GROQ_API_KEY_EDIT) {
      return NextResponse.json({ success: false, error: 'GROQ_API_KEY_EDIT missing' }, { status: 500 });
    }

    const { script, format, videoDuration } = await req.json();

    if (!script) {
      return NextResponse.json({ success: false, error: 'Missing script' }, { status: 400 });
    }

    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY_EDIT });

    const prompt = `
      You are an expert viral video editor. I have a video script for a ${format} video.
      SCRIPT: "${script}"
      VIDEO DURATION: ${videoDuration} seconds.
      
      TASK: Analyze the script and suggest high-quality VISUAL GRAPHICS (no text overlays).
      For each visual, provide:
      1. "prompt": A clear description of the graphic (e.g., "3D glowing neon arrow pointing down, black background", "transparent icon of a mobile phone with a red cross").
      2. "startTime" and "endTime": When it should appear on screen (must be within 0 to ${videoDuration}).
      3. "layout": Choose the best layout from this list:
         - "full": Full screen B-roll.
         - "half_top" / "half_bottom": (Use for ${format === '9:16' ? 'Vertical format' : 'Horizontal format'}).
         - "half_left" / "half_right": (Use for ${format === '16:9' ? 'Horizontal format' : 'Vertical format'}).
         - "overlay": Small transparent icon/graphic in the corner.
         - "background": Behind the main video.
         
      OUTPUT FORMAT (Strict JSON, no markdown):
      {
        "visuals": [
          { "prompt": "string", "startTime": 0, "endTime": 3, "layout": "full" }
        ]
      }
      
      RULES:
      - Provide at least 2 visuals based on the script.
      - Keep prompts descriptive for an image generator.
    `;

    let response;
    try {
      response = await groq.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        model: 'openai/gpt-oss-120b',
        temperature: 0.1,
      });
    } catch {
      // Fallback model
      response = await groq.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        model: 'openai/gpt-oss-20b',
        temperature: 0.1,
      });
    }

    const content = response.choices[0]?.message?.content || '';
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      throw new Error("AI did not return valid JSON");
    }

    const parsed = JSON.parse(jsonMatch[0]);
    const validation = MagicEditResponseSchema.safeParse(parsed);

    if (!validation.success) {
      throw new Error(`AI returned invalid structure: ${validation.error.message}`);
    }

    return NextResponse.json({ 
      success: true, 
      data: { visuals: validation.data.visuals } 
    });

  } catch (error: unknown) {
    console.error("Magic Edit API Error:", error);
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}