'use client';

import { useCallback, useEffect, useRef, useState, type RefObject } from 'react';
import { applyAlphaMatteToCanvas } from '@/lib/video/applyAlphaMatte';
import { getRvmEngine } from '@/lib/video/cutoutEngine';

export type CutoutStatus = 'idle' | 'loading' | 'ready' | 'error';

export interface UseRvmCutoutOptions {
      enabled: boolean;
      videoRef: RefObject<HTMLVideoElement | null>;
      canvasRef: RefObject<HTMLCanvasElement | null>;
      previewMaxWidth?: number;
      refineStrength?: number;
      featherAmount?: number;
      temporalSmoothing?: number;
      backgroundColor?: [number, number, number, number] | null;
}

export interface UseRvmCutoutResult {
      status: CutoutStatus;
      ep: string;
      error: string | null;
      fps: number;
      inferenceMs: number;
      drawAsync: () => void;
}

export function useRvmCutout(opts: UseRvmCutoutOptions): UseRvmCutoutResult {
      const [status, setStatus] = useState<CutoutStatus>('idle');
      const [ep, setEp] = useState('');
      const [error, setError] = useState<string | null>(null);
      const [fps, setFps] = useState(0);
      const [inferenceMs, setInferenceMs] = useState(0);

      const engineRef = useRef<ReturnType<typeof getRvmEngine> | null>(null);
      const prevAlphaRef = useRef<Uint8ClampedArray | null>(null);
      const lastFrameTimeRef = useRef(0);
      const fpsSamplesRef = useRef<number[]>([]);

      useEffect(() => {
            if (!opts.enabled) {
                  setStatus('idle');
                  prevAlphaRef.current = null;
                  return;
            }

            let cancelled = false;
            setError(null);

            const engine = getRvmEngine();
            engineRef.current = engine;

            if (engine.isReady()) {
                  setStatus('ready');
                  setEp((previous) => previous || 'cached');
                  return () => {
                        cancelled = true;
                  };
            }

            setStatus('loading');
            void (async () => {
                  try {
                        const epName = await engine.init();
                        if (cancelled) {
                              return;
                        }
                        setEp(epName);
                        setStatus('ready');
                  } catch (cause) {
                        if (cancelled) {
                              return;
                        }
                        setStatus('error');
                        setError(cause instanceof Error ? cause.message : String(cause));
                  }
            })();

            return () => {
                  cancelled = true;
            };
      }, [opts.enabled]);

      const drawAsync = useCallback(() => {
            if (status !== 'ready') {
                  return;
            }

            const video = opts.videoRef.current;
            const canvas = opts.canvasRef.current;
            const engine = engineRef.current;
            if (!video || !canvas || !engine || video.readyState < 2 || engine.isBusy()) {
                  return;
            }

            const videoWidth = video.videoWidth;
            const videoHeight = video.videoHeight;
            if (!videoWidth || !videoHeight) {
                  return;
            }

            const maxWidth = opts.previewMaxWidth ?? 854;
            const scale = Math.min(1, maxWidth / videoWidth);
            const width = Math.round(videoWidth * scale);
            const height = Math.round(videoHeight * scale);

            const offscreenCanvas = new OffscreenCanvas(width, height);
            const offscreenContext = offscreenCanvas.getContext('2d', {
                  willReadFrequently: true,
            });
            if (!offscreenContext) {
                  return;
            }

            offscreenContext.drawImage(video, 0, 0, width, height);
            const bitmap = offscreenCanvas.transferToImageBitmap();

            const context = canvas.getContext('2d', { willReadFrequently: true });
            if (context) {
                  if (canvas.width !== videoWidth || canvas.height !== videoHeight) {
                        canvas.width = videoWidth;
                        canvas.height = videoHeight;
                  }
                  context.drawImage(video, 0, 0, videoWidth, videoHeight);
            }

            void engine
                  .process(bitmap, width, height)
                  .then((result) => {
                        if (!result || !context) {
                              return;
                        }

                        const newAlpha = applyAlphaMatteToCanvas(
                              context,
                              result.alpha,
                              result.matteWidth,
                              result.matteHeight,
                              videoWidth,
                              videoHeight,
                              prevAlphaRef.current,
                              {
                                    featherAmount: opts.featherAmount ?? 0.35,
                                    temporalSmoothing: opts.temporalSmoothing ?? 0.3,
                                    refineStrength: opts.refineStrength ?? 1,
                                    backgroundColor: opts.backgroundColor ?? null,
                              },
                        );
                        prevAlphaRef.current = newAlpha;

                        const now = performance.now();
                        if (lastFrameTimeRef.current > 0) {
                              const delta = now - lastFrameTimeRef.current;
                              if (delta > 0 && delta < 1000) {
                                    fpsSamplesRef.current.push(1000 / delta);
                                    if (fpsSamplesRef.current.length > 15) {
                                          fpsSamplesRef.current.shift();
                                    }
                                    const average =
                                          fpsSamplesRef.current.reduce(
                                                (total, sample) => total + sample,
                                                0,
                                          ) / fpsSamplesRef.current.length;
                                    setFps(Math.round(average));
                              }
                        }
                        lastFrameTimeRef.current = now;
                        setInferenceMs(result.inferenceMs);
                  })
                  .catch((cause: unknown) => {
                        setError(cause instanceof Error ? cause.message : String(cause));
                  });
      }, [
            status,
            opts.videoRef,
            opts.canvasRef,
            opts.previewMaxWidth,
            opts.featherAmount,
            opts.temporalSmoothing,
            opts.refineStrength,
            opts.backgroundColor,
      ]);

      return { status, ep, error, fps, inferenceMs, drawAsync };
}
