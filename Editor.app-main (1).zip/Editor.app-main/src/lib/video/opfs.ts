// OPFS Helper for storing videos locally

export async function saveVideoToOPFS(draftId: string, file: File) {
  try {
      const root = await navigator.storage.getDirectory();
          const draftsDir = await root.getDirectoryHandle("drafts", { create: true });
              const draftDir = await draftsDir.getDirectoryHandle(draftId, { create: true });
                  const fileHandle = await draftDir.getFileHandle("video.mp4", { create: true });
                      
                          const writable = await fileHandle.createWritable();
                              await writable.write(file);
                                  await writable.close();
                                      
                                          return true;
                                            } catch (error) {
                                                console.error("OPFS Save Error:", error);
                                                    return false;
                                                      }
                                                      }

                                                      export async function getVideoFromOPFS(draftId: string): Promise<File | null> {
                                                        try {
                                                            const root = await navigator.storage.getDirectory();
                                                                const draftsDir = await root.getDirectoryHandle("drafts");
                                                                    const draftDir = await draftsDir.getDirectoryHandle(draftId);
                                                                        const fileHandle = await draftDir.getFileHandle("video.mp4");
                                                                            
                                                                                return await fileHandle.getFile();
                                                                                  } catch (error) {
                                                                                      if (error instanceof DOMException && error.name === "NotFoundError") {
                                                                                        return null;
                                                                                      }
                                                                                      throw error;
                                                                                                                    }
                                                                                            }

                                                                                            export async function deleteVideoFromOPFS(draftId: string) {
                                                                                              try {
                                                                                                  const root = await navigator.storage.getDirectory();
                                                                                                      const draftsDir = await root.getDirectoryHandle("drafts");
                                                                                                          await draftsDir.removeEntry(draftId, { recursive: true });
                                                                                                            } catch (error) {
                                                                                                                console.error("OPFS Delete Error:", error);
                                                                                                                  }
                                                                                                                  }