export interface CutoutResult {
      alpha: Uint8ClampedArray;
      matteWidth: number;
      matteHeight: number;
      srcWidth: number;
      srcHeight: number;
      inferenceMs: number;
      ep: string;
}

export interface RvmEngineOptions {
      rvmModelUrl?: string;
      rvmWasmPaths?: string | Record<string, string>;
      rvmRatio?: number;
      onReady?: (ep: string) => void;
      onError?: (msg: string) => void;
}

type WorkerResponse =
      | { type: 'ready'; ep: string }
      | { type: 'result'; alpha: ArrayBuffer; matteWidth: number; matteHeight: number; srcWidth: number; srcHeight: number; inferenceMs: number; ep: string }
      | { type: 'error'; message: string }
      | { type: 'reset-ok' }
      | { type: 'disposed' };

export class RvmEngine {
      private worker: Worker | null = null;
      private ready = false;
      private inFlight = false;
      private pendingResolve: ((result: CutoutResult) => void) | null = null;
      private pendingReject: ((error: Error) => void) | null = null;
      private initPromise: Promise<string> | null = null;
      private initReject: ((error: Error) => void) | null = null;
      private initCleanup: (() => void) | null = null;
      private ep = 'unknown';
      private options: RvmEngineOptions;

      constructor(options: RvmEngineOptions = {}) {
            this.options = options;
      }

      async init(): Promise<string> {
            if (this.ready) {
                  return this.ep;
            }
            if (this.initPromise) {
                  return this.initPromise;
            }

            if (!this.worker) {
                  this.worker = new Worker(new URL('../../workers/rvm.worker.ts', import.meta.url), {
                        type: 'module',
                  });
                  this.worker.onmessage = (event: MessageEvent<WorkerResponse>) =>
                        this.handleMessage(event);
                  this.worker.onerror = (event) => {
                        const error = new Error(event.message || 'RVM worker failed');
                        this.options.onError?.(error.message);
                        this.initReject?.(error);
                        this.initCleanup?.();
                        this.rejectPending(error);
                  };
            }

            const worker = this.worker;
            this.initPromise = new Promise<string>((resolve, reject) => {
                  const timeout = setTimeout(() => {
                        cleanup();
                        reject(new Error('RVM init timeout (>60s)'));
                  }, 60_000);

                  const cleanup = () => {
                        clearTimeout(timeout);
                        worker.removeEventListener('message', handleInitMessage);
                        this.initCleanup = null;
                        this.initReject = null;
                  };

                  const handleInitMessage = (event: MessageEvent<WorkerResponse>) => {
                        if (event.data.type === 'ready') {
                              cleanup();
                              this.ready = true;
                              this.ep = event.data.ep;
                              this.options.onReady?.(event.data.ep);
                              resolve(event.data.ep);
                        } else if (event.data.type === 'error') {
                              cleanup();
                              reject(new Error(event.data.message));
                        }
                  };

                  this.initReject = reject;
                  this.initCleanup = cleanup;
                  worker.addEventListener('message', handleInitMessage);
                  worker.postMessage({
                        type: 'init',
                        modelUrl: this.options.rvmModelUrl ?? '/models/rvm_mobilenetv3_fp32.onnx',
                        wasmPaths: this.options.rvmWasmPaths,
                        ratio: this.options.rvmRatio ?? 0.375,
                  });
            }).finally(() => {
                  this.initPromise = null;
            });

            return this.initPromise;
      }

      private handleMessage(event: MessageEvent<WorkerResponse>): void {
            const msg = event.data;

            if (msg.type === 'result' && this.pendingResolve) {
                  const result: CutoutResult = {
                        alpha: new Uint8ClampedArray(msg.alpha),
                        matteWidth: msg.matteWidth,
                        matteHeight: msg.matteHeight,
                        srcWidth: msg.srcWidth,
                        srcHeight: msg.srcHeight,
                        inferenceMs: msg.inferenceMs,
                        ep: msg.ep,
                  };
                  const resolve = this.pendingResolve;
                  this.pendingResolve = null;
                  this.pendingReject = null;
                  this.inFlight = false;
                  resolve(result);
            }

            if (msg.type === 'error') {
                  this.options.onError?.(msg.message);
                  if (this.pendingReject) {
                        this.rejectPending(new Error(msg.message));
                  }
            }
      }

      private rejectPending(error: Error): void {
            const reject = this.pendingReject;
            this.pendingResolve = null;
            this.pendingReject = null;
            this.inFlight = false;
            reject?.(error);
      }

      /**
       * Process one frame. The caller transfers ownership of the ImageBitmap.
       * Returns null if a frame is already being processed (drop-frame strategy).
       */
      async process(
            bitmap: ImageBitmap,
            width: number,
            height: number,
      ): Promise<CutoutResult | null> {
            if (!this.worker || !this.ready) {
                  bitmap.close();
                  throw new Error('RVM not ready');
            }
            if (this.inFlight) {
                  bitmap.close();
                  return null;
            }

            this.inFlight = true;
            return new Promise<CutoutResult>((resolve, reject) => {
                  this.pendingResolve = resolve;
                  this.pendingReject = reject;

                  try {
                        this.worker!.postMessage(
                              {
                                    type: 'process',
                                    bitmap,
                                    width,
                                    height,
                                    ratio: this.options.rvmRatio,
                              },
                              [bitmap],
                        );
                  } catch (error) {
                        this.rejectPending(
                              error instanceof Error ? error : new Error(String(error)),
                        );
                        bitmap.close();
                  }
            });
      }

      isReady(): boolean {
            return this.ready;
      }

      isBusy(): boolean {
            return this.inFlight;
      }

      async dispose(): Promise<void> {
            if (this.worker) {
                  this.worker.terminate();
                  this.worker = null;
            }
            this.initReject?.(new Error('RVM engine disposed'));
            this.initCleanup?.();
            this.ready = false;
            this.ep = 'unknown';
            this.initPromise = null;
            this.rejectPending(new Error('RVM engine disposed'));
      }
}

let instance: RvmEngine | null = null;

export function getRvmEngine(options?: RvmEngineOptions): RvmEngine {
      if (!instance) {
            instance = new RvmEngine(options);
      }
      return instance;
}

export async function disposeRvmEngine(): Promise<void> {
      if (instance) {
            await instance.dispose();
            instance = null;
      }
}
