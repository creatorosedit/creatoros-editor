export interface ApplyOptions {
      /** 0 = sharp edges (jaggy), 1 = soft (blurry), 0.3-0.5 recommended */
      featherAmount?: number;
      /** 0 = no smoothing, 1 = max smoothing. 0.3 recommended for 4GB phone */
      temporalSmoothing?: number;
      /** Render background color as RGBA when alpha=0. null = transparent. */
      backgroundColor?: [number, number, number, number] | null;
      /** Global alpha multiplier (0-1). Useful for slider "Refine". */
      refineStrength?: number;
}

const DEFAULT_OPTS: Required<ApplyOptions> = {
      featherAmount: 0.35,
      temporalSmoothing: 0.3,
      backgroundColor: [0, 0, 0, 0],
      refineStrength: 1.0,
};

/**
 * Composite matte onto a canvas.
 * @param sourceCtx Canvas 2D context containing the original video frame (already drawn)
 * @param matte Alpha matte (Uint8ClampedArray, size matteW*matteH)
 * @param matteW Matte width
 * @param matteH Matte height
 * @param srcW Source canvas width
 * @param srcH Source canvas height
 * @param prevAlpha Previous frame's full-res alpha for temporal smoothing
 * @param opts Apply options
 * @returns Updated full-res alpha for next-frame smoothing
 */
export function applyAlphaMatteToCanvas(
      sourceCtx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
      matte: Uint8ClampedArray,
      matteW: number,
      matteH: number,
      srcW: number,
      srcH: number,
      prevAlpha: Uint8ClampedArray | null,
      opts: ApplyOptions = {},
): Uint8ClampedArray {
      const options = { ...DEFAULT_OPTS, ...opts };

      const upscaled = upscaleBilinear(matte, matteW, matteH, srcW, srcH);

      const featherRadius = Math.max(0, Math.round(options.featherAmount * 4));
      const feathered =
            featherRadius > 0
                  ? boxBlurAlpha(upscaled, srcW, srcH, featherRadius)
                  : upscaled;

      let smoothed = feathered;
      if (
            prevAlpha &&
            prevAlpha.length === feathered.length &&
            options.temporalSmoothing > 0
      ) {
            const smoothing = Math.min(1, Math.max(0, options.temporalSmoothing));
            const inverseSmoothing = 1 - smoothing;
            smoothed = new Uint8ClampedArray(feathered.length);
            for (let i = 0; i < feathered.length; i++) {
                  smoothed[i] =
                        feathered[i]! * inverseSmoothing + prevAlpha[i]! * smoothing;
            }
      }

      const image = sourceCtx.getImageData(0, 0, srcW, srcH);
      const data = image.data;
      const refineStrength = Math.min(1, Math.max(0, options.refineStrength));

      for (let i = 0, pixel = 0; i < smoothed.length; i++, pixel += 4) {
            const alpha = smoothed[i]! * refineStrength;
            if (options.backgroundColor) {
                  const backgroundAlpha = options.backgroundColor[3];
                  const foregroundAlpha = alpha / 255;
                  const compositedBackgroundAlpha =
                        (backgroundAlpha / 255) * (1 - foregroundAlpha);
                  const outputAlpha = foregroundAlpha + compositedBackgroundAlpha;
                  if (outputAlpha > 0) {
                        data[pixel] =
                              (data[pixel]! * foregroundAlpha +
                                    options.backgroundColor[0] *
                                          compositedBackgroundAlpha) /
                              outputAlpha;
                        data[pixel + 1] =
                              (data[pixel + 1]! * foregroundAlpha +
                                    options.backgroundColor[1] *
                                          compositedBackgroundAlpha) /
                              outputAlpha;
                        data[pixel + 2] =
                              (data[pixel + 2]! * foregroundAlpha +
                                    options.backgroundColor[2] *
                                          compositedBackgroundAlpha) /
                              outputAlpha;
                  }
                  data[pixel + 3] = outputAlpha * 255;
            } else {
                  data[pixel + 3] = (data[pixel + 3]! * alpha) / 255;
            }
      }
      sourceCtx.putImageData(image, 0, 0);

      return smoothed;
}

function upscaleBilinear(
      src: Uint8ClampedArray,
      sw: number,
      sh: number,
      dw: number,
      dh: number,
): Uint8ClampedArray {
      if (sw === dw && sh === dh) {
            return src;
      }

      const output = new Uint8ClampedArray(dw * dh);
      const xRatio = sw / dw;
      const yRatio = sh / dh;

      for (let y = 0; y < dh; y++) {
            const sourceY = y * yRatio;
            const y0 = Math.floor(sourceY);
            const y1 = Math.min(sh - 1, y0 + 1);
            const fy = sourceY - y0;

            for (let x = 0; x < dw; x++) {
                  const sourceX = x * xRatio;
                  const x0 = Math.floor(sourceX);
                  const x1 = Math.min(sw - 1, x0 + 1);
                  const fx = sourceX - x0;

                  const a = src[y0 * sw + x0]!;
                  const b = src[y0 * sw + x1]!;
                  const c = src[y1 * sw + x0]!;
                  const d = src[y1 * sw + x1]!;

                  const top = a + (b - a) * fx;
                  const bottom = c + (d - c) * fx;
                  output[y * dw + x] = top + (bottom - top) * fy;
            }
      }
      return output;
}

function boxBlurAlpha(
      src: Uint8ClampedArray,
      width: number,
      height: number,
      radius: number,
): Uint8ClampedArray {
      const temp = new Uint8ClampedArray(src.length);
      const output = new Uint8ClampedArray(src.length);
      const r = Math.max(1, radius);
      const divisor = r * 2 + 1;

      for (let y = 0; y < height; y++) {
            const row = y * width;
            let sum = 0;
            for (let x = -r; x <= r; x++) {
                  sum += src[row + Math.min(width - 1, Math.max(0, x))]!;
            }
            for (let x = 0; x < width; x++) {
                  temp[row + x] = sum / divisor;
                  const add = src[row + Math.min(width - 1, x + r + 1)]!;
                  const subtract = src[row + Math.max(0, x - r)]!;
                  sum += add - subtract;
            }
      }

      for (let x = 0; x < width; x++) {
            let sum = 0;
            for (let y = -r; y <= r; y++) {
                  sum += temp[Math.min(height - 1, Math.max(0, y)) * width + x]!;
            }
            for (let y = 0; y < height; y++) {
                  output[y * width + x] = sum / divisor;
                  const add = temp[Math.min(height - 1, y + r + 1) * width + x]!;
                  const subtract = temp[Math.max(0, y - r) * width + x]!;
                  sum += add - subtract;
            }
      }

      return output;
}
