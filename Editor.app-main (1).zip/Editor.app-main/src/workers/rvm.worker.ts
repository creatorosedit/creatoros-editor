import * as ort from 'onnxruntime-web';

type WorkerMessage =
      | {
                  type: 'init';
                  modelUrl: string;
                  wasmPaths?: string | Record<string, string>;
                  ratio?: number;
            }
      | { type: 'reset' }
      | { type: 'dispose' }
      | {
                  type: 'process';
                  bitmap: ImageBitmap;
                  width: number;
                  height: number;
                  ratio?: number;
            };

let session: ort.InferenceSession | null = null;
let rec: ort.Tensor[] | null = null;
let currentRatio = 0.375;
let epLabel = 'unknown';

const makeInitStates = (): ort.Tensor[] => [
      new ort.Tensor('float32', new Float32Array([1]), [1, 1, 1, 1]),
      new ort.Tensor('float32', new Float32Array([1]), [1, 1, 1, 1]),
      new ort.Tensor('float32', new Float32Array([1]), [1, 1, 1, 1]),
      new ort.Tensor('float32', new Float32Array([1]), [1, 1, 1, 1]),
];

self.onmessage = async (event: MessageEvent<WorkerMessage>) => {
      const msg = event.data;

      try {
            if (msg.type === 'init') {
                  ort.env.wasm.numThreads = 1;
                  ort.env.wasm.wasmPaths =
                        msg.wasmPaths ?? 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/';
                  ort.env.logLevel = 'error';

                  const hasGpu = typeof navigator !== 'undefined' && 'gpu' in navigator;
                  const executionProviders = hasGpu ? ['webgpu', 'wasm'] : ['wasm'];
                  const eps: 'wasm'[] = ['wasm'];

                  try {
                        session = await ort.InferenceSession.create(msg.modelUrl, {
                              executionProviders,
                              graphOptimizationLevel: 'all',
                        });
                        epLabel = hasGpu ? 'webgpu/wasm' : 'wasm';
                  } catch {
                        session = await ort.InferenceSession.create(msg.modelUrl, {
                              executionProviders: eps,
                              graphOptimizationLevel: 'all',
                        });
                        epLabel = 'wasm';
                  }

                  rec = makeInitStates();
                  currentRatio = msg.ratio ?? 0.375;
                  self.postMessage({ type: 'ready', ep: epLabel });
                  return;
            }

            if (msg.type === 'reset') {
                  rec = makeInitStates();
                  self.postMessage({ type: 'reset-ok' });
                  return;
            }

            if (msg.type === 'dispose') {
                  await session?.release();
                  session = null;
                  rec = null;
                  self.postMessage({ type: 'disposed' });
                  return;
            }

            if (msg.type === 'process') {
                  if (!session || !rec) {
                        self.postMessage({ type: 'error', message: 'worker not initialized' });
                        return;
                  }

                  const { bitmap, width, height, ratio } = msg;
                  const w = width;
                  const h = height;
                  const r = ratio ?? currentRatio;

                  if (r !== currentRatio) {
                        rec = makeInitStates();
                        currentRatio = r;
                  }

                  const canvas = new OffscreenCanvas(w, h);
                  const ctx = canvas.getContext('2d', { willReadFrequently: true });
                  if (!ctx) {
                        bitmap.close();
                        throw new Error('Could not create a 2D canvas context');
                  }

                  ctx.drawImage(bitmap, 0, 0, w, h);
                  bitmap.close();
                  const data = ctx.getImageData(0, 0, w, h).data;

                  const plane = w * h;
                  const src = new Float32Array(3 * plane);
                  for (let i = 0; i < plane; i++) {
                        const p = i * 4;
                        src[i] = data[p]! / 255;
                        src[plane + i] = data[p + 1]! / 255;
                        src[2 * plane + i] = data[p + 2]! / 255;
                  }

                  const feeds: Record<string, ort.Tensor> = {
                        src: new ort.Tensor('float32', src, [1, 3, h, w]),
                        downsample_ratio: new ort.Tensor('float32', new Float32Array([r]), [1]),
                        r1i: rec[0]!,
                        r2i: rec[1]!,
                        r3i: rec[2]!,
                        r4i: rec[3]!,
                  };

                  const t0 = performance.now();
                  console.log('[RVM Worker] Starting inference', w, h);
                  const out = await Promise.race([
                        session.run(feeds),
                        new Promise<never>((_, reject) =>
                              setTimeout(() => reject(new Error('RVM Inference Timeout (5s)')), 5000),
                        ),
                  ]);
                  const inferenceMs = Math.round(performance.now() - t0);
                  console.log('[RVM Worker] Inference done', inferenceMs + 'ms');

                  if (!out.pha || !out.r1o || !out.r2o || !out.r3o || !out.r4o) {
                        throw new Error('ONNX model returned incomplete outputs');
                  }

                  rec = [out.r1o, out.r2o, out.r3o, out.r4o];

                  const pha = out.pha.data as Float32Array;
                  const matteH = out.pha.dims[2]!;
                  const matteW = out.pha.dims[3]!;
                  const alpha = new Uint8ClampedArray(pha.length);
                  for (let i = 0; i < pha.length; i++) {
                        const value = pha[i]!;
                        alpha[i] = value < 0 ? 0 : value > 1 ? 255 : value * 255;
                  }

                  self.postMessage(
                        {
                              type: 'result',
                              alpha: alpha.buffer,
                              matteWidth: matteW,
                              matteHeight: matteH,
                              srcWidth: w,
                              srcHeight: h,
                              inferenceMs,
                              ep: epLabel,
                        },
                        [alpha.buffer],
                  );
            }
      } catch (error) {
            console.error('[RVM Worker Error]', error);
            self.postMessage({
                  type: 'error',
                  message: error instanceof Error ? error.message : String(error),
            });
      }
};

export {};
